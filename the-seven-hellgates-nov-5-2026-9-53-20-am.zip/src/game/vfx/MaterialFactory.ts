/**
 * The Seven Hellgates - Advanced PBR Material & Texture Factory
 * Generates procedural high-resolution normal maps, roughness maps, emissive maps,
 * and PBR materials for Azrael's gothic armor, skin, hair, and distinct demon archetypes.
 * 100% code-driven with zero 404 image dependencies; optimized for mobile Safari & desktop WebGL.
 */

import * as THREE from 'three';

class MaterialFactory {
  // Shared Procedural Textures
  private steelNormalMap: THREE.CanvasTexture | null = null;
  private steelRoughnessMap: THREE.CanvasTexture | null = null;
  private steelColorMap: THREE.CanvasTexture | null = null;
  private armorRuneEmissiveMap: THREE.CanvasTexture | null = null;

  private leatherNormalMap: THREE.CanvasTexture | null = null;
  private leatherColorMap: THREE.CanvasTexture | null = null;

  private skinNormalMap: THREE.CanvasTexture | null = null;
  private skinRoughnessMap: THREE.CanvasTexture | null = null;
  private hairNormalMap: THREE.CanvasTexture | null = null;

  private clothNormalMap: THREE.CanvasTexture | null = null;
  private runeGlowMap: THREE.CanvasTexture | null = null;
  private stoneNormalMap: THREE.CanvasTexture | null = null;

  // Demon Textures
  private hellspawnFleshMap: THREE.CanvasTexture | null = null;
  private hellspawnNormalMap: THREE.CanvasTexture | null = null;

  private volcanicArmorMap: THREE.CanvasTexture | null = null;
  private volcanicEmissiveMap: THREE.CanvasTexture | null = null;
  private volcanicNormalMap: THREE.CanvasTexture | null = null;

  private spectralShroudMap: THREE.CanvasTexture | null = null;
  private spectralNormalMap: THREE.CanvasTexture | null = null;

  constructor() {
    this.generateAllTextures();
  }

  private generateAllTextures() {
    // 1. Azrael Gothic Steel Armor Textures
    const steel = this.createDamascusSteelTextures(512, 512);
    this.steelNormalMap = steel.normal;
    this.steelRoughnessMap = steel.roughness;
    this.steelColorMap = steel.color;
    this.armorRuneEmissiveMap = this.createArmorRuneEmissiveTexture(256, 512);

    // 2. Weathered Battled Leather Textures
    const leather = this.createLeatherTextures(512, 512);
    this.leatherNormalMap = leather.normal;
    this.leatherColorMap = leather.color;

    // 3. Natural Skin & Hair Textures
    const skin = this.createSkinTextures(512, 512);
    this.skinNormalMap = skin.normal;
    this.skinRoughnessMap = skin.roughness;
    this.hairNormalMap = this.createHairStrandNormalTexture(256, 256);

    // 4. Fabric & Runes
    this.clothNormalMap = this.createClothNormalTexture(512, 512);
    this.runeGlowMap = this.createRuneGlowTexture(256, 1024);
    this.stoneNormalMap = this.createStoneNormalTexture(512, 512);

    // 5. Demon Textures (Hellspawn, Hellbrute, Shade)
    const hellspawn = this.createHellspawnTextures(512, 512);
    this.hellspawnFleshMap = hellspawn.color;
    this.hellspawnNormalMap = hellspawn.normal;

    const volcanic = this.createVolcanicCrackedTextures(512, 512);
    this.volcanicArmorMap = volcanic.color;
    this.volcanicEmissiveMap = volcanic.emissive;
    this.volcanicNormalMap = volcanic.normal;

    const spectral = this.createSpectralSmokeTextures(512, 512);
    this.spectralShroudMap = spectral.color;
    this.spectralNormalMap = spectral.normal;
  }

  // =========================================================================
  // 1. AZRAEL DAMASCUS GOTHIC STEEL PROCEDURAL TEXTURES
  // =========================================================================

  private createDamascusSteelTextures(width: number, height: number): {
    color: THREE.CanvasTexture;
    normal: THREE.CanvasTexture;
    roughness: THREE.CanvasTexture;
  } {
    const canvasC = document.createElement('canvas');
    canvasC.width = width; canvasC.height = height;
    const ctxC = canvasC.getContext('2d')!;

    const canvasN = document.createElement('canvas');
    canvasN.width = width; canvasN.height = height;
    const ctxN = canvasN.getContext('2d')!;

    const canvasR = document.createElement('canvas');
    canvasR.width = width; canvasR.height = height;
    const ctxR = canvasR.getContext('2d')!;

    const imgC = ctxC.createImageData(width, height);
    const dataC = imgC.data;

    const imgN = ctxN.createImageData(width, height);
    const dataN = imgN.data;

    const imgR = ctxR.createImageData(width, height);
    const dataR = imgR.data;

    const heights = new Float32Array(width * height);

    // Generate heightmap with Damascus folds, micro-scratches, and hammered pits
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        // Folded steel wave pattern
        const fold1 = Math.sin(x * 0.08 + Math.cos(y * 0.05) * 3.0);
        const fold2 = Math.sin(y * 0.06 + Math.sin(x * 0.04) * 2.5) * 0.5;
        // Fine brushed striations
        const striation = Math.sin(x * 1.5) * 0.08;
        // Battle scratches
        const scratch = Math.sin(x * 0.2 + y * 0.3) > 0.94 ? 0.35 : 0;
        const pit = (Math.random() - 0.5) * 0.06;

        heights[i] = 0.5 + fold1 * 0.15 + fold2 * 0.1 + striation + scratch + pit;

        // Base Color: Blackened Damascus steel (#12151e) with silver edge highlights (#7d879c)
        const isEdgeOrScratch = scratch > 0 || Math.abs(fold1) > 0.92;
        const rBase = isEdgeOrScratch ? 85 : 18;
        const gBase = isEdgeOrScratch ? 95 : 21;
        const bBase = isEdgeOrScratch ? 115 : 28;

        const idx = i * 4;
        dataC[idx] = Math.min(255, rBase + Math.floor((Math.random() - 0.5) * 6));
        dataC[idx + 1] = Math.min(255, gBase + Math.floor((Math.random() - 0.5) * 6));
        dataC[idx + 2] = Math.min(255, bBase + Math.floor((Math.random() - 0.5) * 6));
        dataC[idx + 3] = 255;

        // Roughness: Polished flats (~0.25), Damascus grain (~0.35), scratches (~0.55)
        const roughVal = isEdgeOrScratch ? 140 : Math.floor(65 + Math.abs(fold1) * 35);
        dataR[idx] = roughVal;
        dataR[idx + 1] = roughVal;
        dataR[idx + 2] = roughVal;
        dataR[idx + 3] = 255;
      }
    }

    // Sobel normal map
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const dx = (heights[y * width + (x + 1)] - heights[y * width + (x - 1)]) * 2.8;
        const dy = (heights[(y + 1) * width + x] - heights[(y - 1) * width + x]) * 2.8;
        const dz = 1.0;

        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dataN[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
        dataN[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
        dataN[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
        dataN[idx + 3] = 255;
      }
    }

    ctxC.putImageData(imgC, 0, 0);
    ctxN.putImageData(imgN, 0, 0);
    ctxR.putImageData(imgR, 0, 0);

    const texC = new THREE.CanvasTexture(canvasC);
    texC.colorSpace = THREE.SRGBColorSpace;
    texC.wrapS = THREE.RepeatWrapping; texC.wrapT = THREE.RepeatWrapping;
    texC.repeat.set(2, 2);

    const texN = new THREE.CanvasTexture(canvasN);
    texN.wrapS = THREE.RepeatWrapping; texN.wrapT = THREE.RepeatWrapping;
    texN.repeat.set(2, 2);

    const texR = new THREE.CanvasTexture(canvasR);
    texR.wrapS = THREE.RepeatWrapping; texR.wrapT = THREE.RepeatWrapping;
    texR.repeat.set(2, 2);

    return { color: texC, normal: texN, roughness: texR };
  }

  /**
   * Subtle Icy-Blue Emissive Runic Armor Inlays
   */
  private createArmorRuneEmissiveTexture(width: number, height: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 3;
    ctx.shadowColor = '#0284c7';
    ctx.shadowBlur = 8;

    // Draw intricate runes running along the armor ridges
    for (let y = 30; y < height - 30; y += 65) {
      ctx.beginPath();
      ctx.moveTo(width * 0.5, y);
      ctx.lineTo(width * 0.5 + 20, y + 20);
      ctx.lineTo(width * 0.5 - 20, y + 35);
      ctx.lineTo(width * 0.5, y + 50);
      ctx.stroke();

      // Flanking occult dots
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(width * 0.5 + 28, y + 25, 2.5, 0, Math.PI * 2);
      ctx.arc(width * 0.5 - 28, y + 25, 2.5, 0, Math.PI * 2);
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  // =========================================================================
  // 2. WEATHERED LEATHER PROCEDURAL TEXTURES
  // =========================================================================

  private createLeatherTextures(width: number, height: number): {
    color: THREE.CanvasTexture;
    normal: THREE.CanvasTexture;
  } {
    const canvasC = document.createElement('canvas');
    canvasC.width = width; canvasC.height = height;
    const ctxC = canvasC.getContext('2d')!;

    const canvasN = document.createElement('canvas');
    canvasN.width = width; canvasN.height = height;
    const ctxN = canvasN.getContext('2d')!;

    const imgC = ctxC.createImageData(width, height);
    const dataC = imgC.data;

    const imgN = ctxN.createImageData(width, height);
    const dataN = imgN.data;

    const heights = new Float32Array(width * height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        // Pebbled leather cellular pattern
        const cell = Math.sin(x * 0.25) * Math.cos(y * 0.25);
        const fine = (Math.random() - 0.5) * 0.15;
        heights[i] = 0.5 + cell * 0.35 + fine;

        const idx = i * 4;
        // Deep worn brown-black leather (#281d18)
        const tone = Math.floor(cell * 15);
        dataC[idx] = Math.max(20, 36 + tone);
        dataC[idx + 1] = Math.max(15, 26 + tone);
        dataC[idx + 2] = Math.max(10, 20 + tone);
        dataC[idx + 3] = 255;
      }
    }

    // Normal map
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const dx = (heights[y * width + (x + 1)] - heights[y * width + (x - 1)]) * 3.0;
        const dy = (heights[(y + 1) * width + x] - heights[(y - 1) * width + x]) * 3.0;
        const dz = 1.0;
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

        dataN[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
        dataN[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
        dataN[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
        dataN[idx + 3] = 255;
      }
    }

    ctxC.putImageData(imgC, 0, 0);
    ctxN.putImageData(imgN, 0, 0);

    const texC = new THREE.CanvasTexture(canvasC);
    texC.colorSpace = THREE.SRGBColorSpace;
    texC.wrapS = THREE.RepeatWrapping; texC.wrapT = THREE.RepeatWrapping;
    texC.repeat.set(3, 3);

    const texN = new THREE.CanvasTexture(canvasN);
    texN.wrapS = THREE.RepeatWrapping; texN.wrapT = THREE.RepeatWrapping;
    texN.repeat.set(3, 3);

    return { color: texC, normal: texN };
  }

  // =========================================================================
  // 3. NATURAL SKIN & HAIR PROCEDURAL TEXTURES
  // =========================================================================

  private createSkinTextures(width: number, height: number): {
    normal: THREE.CanvasTexture;
    roughness: THREE.CanvasTexture;
  } {
    const canvasN = document.createElement('canvas');
    canvasN.width = width; canvasN.height = height;
    const ctxN = canvasN.getContext('2d')!;

    const canvasR = document.createElement('canvas');
    canvasR.width = width; canvasR.height = height;
    const ctxR = canvasR.getContext('2d')!;

    const imgN = ctxN.createImageData(width, height);
    const dataN = imgN.data;

    const imgR = ctxR.createImageData(width, height);
    const dataR = imgR.data;

    const heights = new Float32Array(width * height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        // Micro skin pores and fine dermatoglyphic wrinkles
        const pore = Math.sin(x * 1.8) * Math.cos(y * 1.8) * 0.08;
        const noise = (Math.random() - 0.5) * 0.06;
        heights[i] = 0.5 + pore + noise;

        const idx = i * 4;
        // Skin Roughness: soft matte skin (0.68 to 0.74), zero plastic shine
        const rVal = Math.floor(175 + pore * 40);
        dataR[idx] = rVal;
        dataR[idx + 1] = rVal;
        dataR[idx + 2] = rVal;
        dataR[idx + 3] = 255;
      }
    }

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const dx = (heights[y * width + (x + 1)] - heights[y * width + (x - 1)]) * 1.8;
        const dy = (heights[(y + 1) * width + x] - heights[(y - 1) * width + x]) * 1.8;
        const dz = 1.0;
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

        dataN[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
        dataN[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
        dataN[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
        dataN[idx + 3] = 255;
      }
    }

    ctxN.putImageData(imgN, 0, 0);
    ctxR.putImageData(imgR, 0, 0);

    const texN = new THREE.CanvasTexture(canvasN);
    texN.wrapS = THREE.RepeatWrapping; texN.wrapT = THREE.RepeatWrapping;
    texN.repeat.set(4, 4);

    const texR = new THREE.CanvasTexture(canvasR);
    texR.wrapS = THREE.RepeatWrapping; texR.wrapT = THREE.RepeatWrapping;
    texR.repeat.set(4, 4);

    return { normal: texN, roughness: texR };
  }

  private createHairStrandNormalTexture(width: number, height: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d')!;

    const img = ctx.createImageData(width, height);
    const data = img.data;

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        // Vertical hair fiber grooves
        const strand = Math.sin(x * 0.8) * 0.4;
        const nx = strand * 0.5 + 0.5;
        const ny = 0.5;
        const nz = 1.0 - Math.abs(strand) * 0.3;

        data[idx] = Math.round(nx * 255);
        data[idx + 1] = Math.round(ny * 255);
        data[idx + 2] = Math.round(nz * 255);
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2, 2);
    return tex;
  }

  // =========================================================================
  // 4. DEMON PROCEDURAL TEXTURES (HELLSPAWN, HELLBRUTE, SHADE)
  // =========================================================================

  /**
   * Hellspawn: Ash-Gray & Dark Crimson Damaged Flesh
   */
  private createHellspawnTextures(width: number, height: number): {
    color: THREE.CanvasTexture;
    normal: THREE.CanvasTexture;
  } {
    const canvasC = document.createElement('canvas');
    canvasC.width = width; canvasC.height = height;
    const ctxC = canvasC.getContext('2d')!;

    const canvasN = document.createElement('canvas');
    canvasN.width = width; canvasN.height = height;
    const ctxN = canvasN.getContext('2d')!;

    const imgC = ctxC.createImageData(width, height);
    const dataC = imgC.data;

    const imgN = ctxN.createImageData(width, height);
    const dataN = imgN.data;

    const heights = new Float32Array(width * height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        // Sinewy organic muscle striations
        const sinew = Math.sin(x * 0.12 + Math.cos(y * 0.08) * 2.0);
        const lesion = Math.sin(x * 0.35 + y * 0.25) > 0.65 ? 0.4 : 0;
        heights[i] = 0.5 + sinew * 0.25 + lesion;

        const idx = i * 4;
        // Mottled ash-gray (#423d3d) with deep crimson muscle tears (#781414)
        if (lesion > 0) {
          dataC[idx] = 135;
          dataC[idx + 1] = 22;
          dataC[idx + 2] = 22;
        } else {
          const ash = Math.floor(55 + sinew * 20);
          dataC[idx] = ash + 12;
          dataC[idx + 1] = ash;
          dataC[idx + 2] = ash;
        }
        dataC[idx + 3] = 255;
      }
    }

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const dx = (heights[y * width + (x + 1)] - heights[y * width + (x - 1)]) * 3.5;
        const dy = (heights[(y + 1) * width + x] - heights[(y - 1) * width + x]) * 3.5;
        const dz = 1.0;
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

        dataN[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
        dataN[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
        dataN[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
        dataN[idx + 3] = 255;
      }
    }

    ctxC.putImageData(imgC, 0, 0);
    ctxN.putImageData(imgN, 0, 0);

    const texC = new THREE.CanvasTexture(canvasC);
    texC.colorSpace = THREE.SRGBColorSpace;
    texC.wrapS = THREE.RepeatWrapping; texC.wrapT = THREE.RepeatWrapping;
    texC.repeat.set(2, 2);

    const texN = new THREE.CanvasTexture(canvasN);
    texN.wrapS = THREE.RepeatWrapping; texN.wrapT = THREE.RepeatWrapping;
    texN.repeat.set(2, 2);

    return { color: texC, normal: texN };
  }

  /**
   * Hellbrute: Thick Dark Hide & Volcanic Cracked Armor with Glowing Fissures
   */
  private createVolcanicCrackedTextures(width: number, height: number): {
    color: THREE.CanvasTexture;
    emissive: THREE.CanvasTexture;
    normal: THREE.CanvasTexture;
  } {
    const canvasC = document.createElement('canvas');
    canvasC.width = width; canvasC.height = height;
    const ctxC = canvasC.getContext('2d')!;

    const canvasE = document.createElement('canvas');
    canvasE.width = width; canvasE.height = height;
    const ctxE = canvasE.getContext('2d')!;

    const canvasN = document.createElement('canvas');
    canvasN.width = width; canvasN.height = height;
    const ctxN = canvasN.getContext('2d')!;

    const imgC = ctxC.createImageData(width, height);
    const dataC = imgC.data;

    const imgE = ctxE.createImageData(width, height);
    const dataE = imgE.data;

    const imgN = ctxN.createImageData(width, height);
    const dataN = imgN.data;

    const heights = new Float32Array(width * height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        // Voronoi-like volcanic crack network
        const n1 = Math.abs(Math.sin(x * 0.08 + Math.cos(y * 0.07) * 2.0));
        const n2 = Math.abs(Math.cos(y * 0.08 + Math.sin(x * 0.07) * 2.0));
        const crack = Math.min(n1, n2);
        const isFissure = crack < 0.12;

        heights[i] = isFissure ? 0.2 : 0.7;

        const idx = i * 4;
        if (isFissure) {
          // Glowing magma vein (#f97316 / #ea580c)
          dataC[idx] = 245;
          dataC[idx + 1] = 115;
          dataC[idx + 2] = 22;

          dataE[idx] = 255;
          dataE[idx + 1] = 95;
          dataE[idx + 2] = 15;
        } else {
          // Thick dark charcoal basalt hide (#1a1819)
          const rock = Math.floor(22 + (Math.random() - 0.5) * 8);
          dataC[idx] = rock;
          dataC[idx + 1] = rock;
          dataC[idx + 2] = rock + 2;

          dataE[idx] = 0;
          dataE[idx + 1] = 0;
          dataE[idx + 2] = 0;
        }
        dataC[idx + 3] = 255;
        dataE[idx + 3] = 255;
      }
    }

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const dx = (heights[y * width + (x + 1)] - heights[y * width + (x - 1)]) * 4.0;
        const dy = (heights[(y + 1) * width + x] - heights[(y - 1) * width + x]) * 4.0;
        const dz = 1.0;
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

        dataN[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
        dataN[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
        dataN[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
        dataN[idx + 3] = 255;
      }
    }

    ctxC.putImageData(imgC, 0, 0);
    ctxE.putImageData(imgE, 0, 0);
    ctxN.putImageData(imgN, 0, 0);

    const texC = new THREE.CanvasTexture(canvasC);
    texC.colorSpace = THREE.SRGBColorSpace;
    texC.wrapS = THREE.RepeatWrapping; texC.wrapT = THREE.RepeatWrapping;
    texC.repeat.set(2, 2);

    const texE = new THREE.CanvasTexture(canvasE);
    texE.colorSpace = THREE.SRGBColorSpace;
    texE.wrapS = THREE.RepeatWrapping; texE.wrapT = THREE.RepeatWrapping;
    texE.repeat.set(2, 2);

    const texN = new THREE.CanvasTexture(canvasN);
    texN.wrapS = THREE.RepeatWrapping; texN.wrapT = THREE.RepeatWrapping;
    texN.repeat.set(2, 2);

    return { color: texC, emissive: texE, normal: texN };
  }

  /**
   * Shade: Nearly Black Supernatural Skin & Smoky Translucent Shroud
   */
  private createSpectralSmokeTextures(width: number, height: number): {
    color: THREE.CanvasTexture;
    normal: THREE.CanvasTexture;
  } {
    const canvasC = document.createElement('canvas');
    canvasC.width = width; canvasC.height = height;
    const ctxC = canvasC.getContext('2d')!;

    const canvasN = document.createElement('canvas');
    canvasN.width = width; canvasN.height = height;
    const ctxN = canvasN.getContext('2d')!;

    const imgC = ctxC.createImageData(width, height);
    const dataC = imgC.data;

    const imgN = ctxN.createImageData(width, height);
    const dataN = imgN.data;

    const heights = new Float32Array(width * height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        // Smoky wisps
        const wisp1 = Math.sin(x * 0.05 + y * 0.04 + Math.sin(y * 0.08) * 1.5);
        const wisp2 = Math.cos(x * 0.04 - y * 0.06) * 0.5;
        const total = (wisp1 + wisp2) * 0.5 + 0.5;
        heights[i] = total;

        const idx = i * 4;
        // Void black with subtle spectral violet smoke edges
        dataC[idx] = Math.floor(10 + total * 25);
        dataC[idx + 1] = Math.floor(8 + total * 15);
        dataC[idx + 2] = Math.floor(20 + total * 45);
        dataC[idx + 3] = 255;
      }
    }

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const dx = (heights[y * width + (x + 1)] - heights[y * width + (x - 1)]) * 2.0;
        const dy = (heights[(y + 1) * width + x] - heights[(y - 1) * width + x]) * 2.0;
        const dz = 1.0;
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

        dataN[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
        dataN[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
        dataN[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
        dataN[idx + 3] = 255;
      }
    }

    ctxC.putImageData(imgC, 0, 0);
    ctxN.putImageData(imgN, 0, 0);

    const texC = new THREE.CanvasTexture(canvasC);
    texC.colorSpace = THREE.SRGBColorSpace;
    texC.wrapS = THREE.RepeatWrapping; texC.wrapT = THREE.RepeatWrapping;
    texC.repeat.set(2, 2);

    const texN = new THREE.CanvasTexture(canvasN);
    texN.wrapS = THREE.RepeatWrapping; texN.wrapT = THREE.RepeatWrapping;
    texN.repeat.set(2, 2);

    return { color: texC, normal: texN };
  }

  // =========================================================================
  // 5. FABRIC & RUNIC UTILITY TEXTURES
  // =========================================================================

  private createClothNormalTexture(width: number, height: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d')!;
    const imgData = ctx.createImageData(width, height);
    const data = imgData.data;

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = (y * width + x) * 4;
        const warp = Math.sin(x * 0.8) * 0.35;
        const weft = Math.sin(y * 0.8) * 0.35;
        data[idx] = Math.round((warp * 0.5 + 0.5) * 255);
        data[idx + 1] = Math.round((weft * 0.5 + 0.5) * 255);
        data[idx + 2] = 230;
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(4, 4);
    return tex;
  }

  private createRuneGlowTexture(width: number, height: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 4;
    ctx.shadowColor = '#38bdf8';
    ctx.shadowBlur = 12;

    for (let y = 40; y < height - 40; y += 80) {
      ctx.beginPath();
      ctx.moveTo(width / 2, y);
      ctx.lineTo(width / 2 + (y % 160 === 0 ? 18 : -18), y + 25);
      ctx.lineTo(width / 2 + (y % 160 === 0 ? -18 : 18), y + 48);
      ctx.lineTo(width / 2, y + 70);
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  private createStoneNormalTexture(width: number, height: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext('2d')!;
    const imgData = ctx.createImageData(width, height);
    const data = imgData.data;
    const heights = new Float32Array(width * height);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = y * width + x;
        const n1 = Math.sin(x * 0.04) * Math.cos(y * 0.04);
        const n2 = Math.sin(x * 0.12 + 1.2) * Math.cos(y * 0.12 + 0.8) * 0.5;
        heights[i] = 0.5 + n1 * 0.3 + n2;
      }
    }

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const idx = (y * width + x) * 4;
        const dx = (heights[y * width + (x + 1)] - heights[y * width + (x - 1)]) * 4.0;
        const dy = (heights[(y + 1) * width + x] - heights[(y - 1) * width + x]) * 4.0;
        const dz = 1.0;
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);

        data[idx] = Math.round(((dx / len) * 0.5 + 0.5) * 255);
        data[idx + 1] = Math.round(((-dy / len) * 0.5 + 0.5) * 255);
        data[idx + 2] = Math.round(((dz / len) * 0.5 + 0.5) * 255);
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(4, 4);
    return tex;
  }

  // =========================================================================
  // PUBLIC MATERIAL FACTORY METHODS
  // =========================================================================

  /**
   * Blackened Damascus Gothic Steel (Azrael's Cuirass & Primary Armor)
   * Detailed battle scratches, worn silver edges, and subtle icy-blue runic inlays
   */
  public createDamascusSteel(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x161822,
      map: this.steelColorMap,
      normalMap: this.steelNormalMap,
      normalScale: new THREE.Vector2(0.85, 0.85),
      roughnessMap: this.steelRoughnessMap,
      roughness: 0.44,
      metalness: 0.86,
      emissive: 0x0284c7,
      emissiveMap: this.armorRuneEmissiveMap,
      emissiveIntensity: 0.15,
    });
  }

  /**
   * Gothic Limb Plates (Vambraces, Greaves, Faulds) - burnished steel with higher edge scratch read
   */
  public createGothicLimbPlate(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x13151d,
      map: this.steelColorMap,
      normalMap: this.steelNormalMap,
      normalScale: new THREE.Vector2(0.75, 0.75),
      roughnessMap: this.steelRoughnessMap,
      roughness: 0.48,
      metalness: 0.82,
    });
  }

  /**
   * Gothic Silver Filigree & Edges (Spine clasp, belt buckle, pauldron rim spikes)
   */
  public createGothicSilver(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x9098aa,
      normalMap: this.steelNormalMap,
      normalScale: new THREE.Vector2(0.4, 0.4),
      roughness: 0.34,
      metalness: 0.88,
    });
  }

  /**
   * Gothic Pauldron Blackened Steel (Shoulder Dome & Primary Lames)
   * Specifically tuned to eliminate excessive metallic reflectivity and white specular glare.
   * Preserves Damascus folding, battle scratches, micro-pits, and cold blue runic inlays.
   */
  public createPauldronBlackenedSteel(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x14161f,
      map: this.steelColorMap,
      normalMap: this.steelNormalMap,
      normalScale: new THREE.Vector2(0.85, 0.85),
      roughnessMap: this.steelRoughnessMap,
      roughness: 0.58, // Satin-matte blackened steel diffuses highlights and avoids mirror washout
      metalness: 0.68, // Moderated from 0.86 to prevent mirror reflection of key light
      emissive: 0x0284c7,
      emissiveMap: this.armorRuneEmissiveMap,
      emissiveIntensity: 0.10,
    });
  }

  /**
   * Gothic Pauldron Worn Edge & Crest Steel (Gardbrace Fin, Outer Lames, and Crest Spike)
   * Replaces overly reflective light silver (0x9098aa) with antique burnished dark gunmetal.
   * Retains worn edges, battle scars, and micro-relief while preventing blinding specular glare.
   */
  public createPauldronWornTrim(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x2e333e, // Antique dark gunmetal trim instead of bright light silver
      normalMap: this.steelNormalMap,
      normalScale: new THREE.Vector2(0.65, 0.65),
      roughnessMap: this.steelRoughnessMap,
      roughness: 0.56, // Increased roughness eliminates blown-out specular highlights on upward-facing fins
      metalness: 0.70, // Balanced metallic response
      emissive: 0x0284c7,
      emissiveIntensity: 0.08,
    });
  }

  /**
   * Weathered Battled Leather Harness Straps & Under-Padding
   */
  public createWeatheredLeather(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x221814,
      map: this.leatherColorMap,
      normalMap: this.leatherNormalMap,
      normalScale: new THREE.Vector2(0.85, 0.85),
      roughness: 0.82,
      metalness: 0.05,
    });
  }

  /**
   * Natural Athletic Male Skin Material (soft epidermal specular, pores, zero plastic shine)
   */
  public createAzraelSkin(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0xb59784,
      normalMap: this.skinNormalMap,
      normalScale: new THREE.Vector2(0.35, 0.35),
      roughnessMap: this.skinRoughnessMap,
      roughness: 0.76,
      metalness: 0.01,
    });
  }

  /**
   * Battle Scar Material (fibrous keloid cicatricial tissue across eye and cheek)
   */
  public createBattleScar(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x441212,
      roughness: 0.88,
      metalness: 0.02,
      normalMap: this.skinNormalMap,
      normalScale: new THREE.Vector2(0.8, 0.8),
    });
  }

  /**
   * Dark Shaggy Hair Material (anisotropic strands, natural matte sheen)
   */
  public createDarkHair(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x090a0e,
      normalMap: this.hairNormalMap,
      normalScale: new THREE.Vector2(0.65, 0.65),
      roughness: 0.84,
      metalness: 0.04,
    });
  }

  /**
   * Pale-Blue Supernatural Glowing Eyes (pupil + glowing cyan iris + cornea shine)
   */
  public createGlowingEyes(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x38bdf8,
      emissiveIntensity: 1.1,
      roughness: 0.15,
      metalness: 0.15,
    });
  }

  /**
   * Crimson/Wine-Red Battle Tabard / Hanging Sash
   */
  public createCrimsonSash(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x6e1b24,
      metalness: 0.03,
      roughness: 0.90,
      normalMap: this.clothNormalMap,
      normalScale: new THREE.Vector2(0.75, 0.75),
      side: THREE.DoubleSide,
    });
  }

  /**
   * Tattered Cowl & Black Battle Cape
   */
  public createTatteredCloth(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x0c0e14,
      metalness: 0.02,
      roughness: 0.94,
      normalMap: this.clothNormalMap,
      normalScale: new THREE.Vector2(0.9, 0.9),
      side: THREE.DoubleSide,
    });
  }

  /**
   * Executioner Greatsword Blade Steel
   */
  public createSwordBladeSteel(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x181c26,
      map: this.steelColorMap,
      normalMap: this.steelNormalMap,
      normalScale: new THREE.Vector2(0.85, 0.85),
      roughness: 0.26,
      metalness: 0.88,
    });
  }

  /**
   * Glowing Supernatural Runic Channel (Executioner Greatsword Fuller)
   */
  public createRunicGlowMaterial(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x0284c7,
      emissive: 0x38bdf8,
      emissiveIntensity: 1.1,
      emissiveMap: this.runeGlowMap,
      map: this.runeGlowMap,
      metalness: 0.75,
      roughness: 0.22,
    });
  }

  // --- DEMON MATERIALS ---

  /**
   * Hellspawn: Ash-Gray & Dark Crimson Flesh
   */
  public createHellspawnFlesh(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x4a2424,
      map: this.hellspawnFleshMap,
      normalMap: this.hellspawnNormalMap,
      normalScale: new THREE.Vector2(1.2, 1.2),
      roughness: 0.68,
      metalness: 0.08,
    });
  }

  /**
   * Hellspawn Bone Scythes & Spikes
   */
  public createHellspawnBone(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x2e2824,
      normalMap: this.steelNormalMap,
      normalScale: new THREE.Vector2(0.9, 0.9),
      roughness: 0.55,
      metalness: 0.25,
    });
  }

  /**
   * Hellspawn Glowing Crimson Eyes
   */
  public createDemonCrimsonEyes(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xff1e1e,
      emissiveIntensity: 2.6,
      roughness: 0.15,
    });
  }

  /**
   * Hellbrute: Thick Dark Hide
   */
  public createHellbruteHide(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x241d1a,
      map: this.leatherColorMap,
      normalMap: this.leatherNormalMap,
      normalScale: new THREE.Vector2(1.4, 1.4),
      roughness: 0.84,
      metalness: 0.05,
    });
  }

  /**
   * Hellbrute: Cracked Volcanic Armor Carapace with Glowing Magma Fissures
   */
  public createVolcanicArmor(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x1f1a18,
      map: this.volcanicArmorMap,
      emissive: 0xea580c,
      emissiveMap: this.volcanicEmissiveMap,
      emissiveIntensity: 1.8,
      normalMap: this.volcanicNormalMap,
      normalScale: new THREE.Vector2(1.5, 1.5),
      roughness: 0.82,
      metalness: 0.35,
    });
  }

  /**
   * Hellbrute Glowing Amber Eyes
   */
  public createDemonAmberEyes(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xfbbf24,
      emissiveIntensity: 2.4,
      roughness: 0.15,
    });
  }

  /**
   * Shade: Nearly Black Supernatural Skin
   */
  public createShadeVoidSkin(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x050608,
      roughness: 0.94,
      metalness: 0.02,
      normalMap: this.spectralNormalMap,
      normalScale: new THREE.Vector2(0.6, 0.6),
    });
  }

  /**
   * Shade: Smoky Translucent Shroud
   */
  public createShadeSpectralShroud(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0x080912,
      map: this.spectralShroudMap,
      normalMap: this.spectralNormalMap,
      normalScale: new THREE.Vector2(0.8, 0.8),
      roughness: 0.90,
      metalness: 0.05,
      transparent: true,
      opacity: 0.86,
      side: THREE.DoubleSide,
    });
  }

  /**
   * Shade Glowing Pale Violet Eyes
   */
  public createShadeVioletEyes(): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0xc084fc,
      emissiveIntensity: 2.6,
      roughness: 0.1,
    });
  }

  /**
   * Ancient Chiseled Arena Basalt Stone
   */
  public createBasaltStone(colorHex: number = 0x181a20): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({
      color: colorHex,
      metalness: 0.15,
      roughness: 0.86,
      normalMap: this.stoneNormalMap,
      normalScale: new THREE.Vector2(1.2, 1.2),
    });
  }
}

export const materialFactory = new MaterialFactory();
