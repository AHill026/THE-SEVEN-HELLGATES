/**
 * The Seven Hellgates - Soulslike Combat System
 * Stamina management, i-frame dodging, hitbox detection, combo chaining, and hitstop.
 */

import * as THREE from 'three';
import { CombatStance, FloatingText, PlayerStats } from '../types';
import { AzraelModel } from '../entities/AzraelModel';
import { EnemyInstance } from '../entities/EnemyModels';
import { BossInstance } from '../entities/BossModels';
import { ParticleSystem } from '../vfx/ParticleSystem';
import { soundEngine } from '../audio/SoundEngine';

export class CombatSystem {
  public health: number;
  public maxHealth: number;
  public stamina: number;
  public maxStamina: number;
  public wrath: number;
  public maxWrath: number = 100;

  private staminaRegenDelay: number = 0;
  private comboStep: number = 1;
  private comboTimer: number = 0;
  public iFramesActive: boolean = false;
  private iFramesTimer: number = 0;
  private hitstopTimer: number = 0;

  public floatingTexts: FloatingText[] = [];

  constructor(stats: PlayerStats) {
    this.maxHealth = 100 + stats.vitality * 15;
    this.health = this.maxHealth;
    this.maxStamina = 80 + stats.vigor * 10;
    this.stamina = this.maxStamina;
    this.wrath = 20;
  }

  public recalculateStats(stats: PlayerStats) {
    const healthPercent = this.health / this.maxHealth;
    this.maxHealth = 100 + stats.vitality * 15;
    this.health = this.maxHealth * healthPercent;

    const stamPercent = this.stamina / this.maxStamina;
    this.maxStamina = 80 + stats.vigor * 10;
    this.stamina = this.maxStamina * stamPercent;
  }

  public update(delta: number): boolean {
    // Return true if hitstop is currently pausing frames
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= delta;
      return true;
    }

    // 1. Stamina Regeneration
    if (this.staminaRegenDelay > 0) {
      this.staminaRegenDelay -= delta;
    } else if (this.stamina < this.maxStamina) {
      this.stamina = Math.min(this.maxStamina, this.stamina + 35 * delta);
    }

    // 2. I-Frames timer
    if (this.iFramesActive) {
      this.iFramesTimer -= delta;
      if (this.iFramesTimer <= 0) {
        this.iFramesActive = false;
      }
    }

    // 3. Combo window decay
    if (this.comboTimer > 0) {
      this.comboTimer -= delta;
      if (this.comboTimer <= 0) {
        this.comboStep = 1;
      }
    }

    // 4. Update floating combat text
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.opacity -= delta * 1.5;
      ft.y -= delta * 30;
      if (ft.opacity <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }

    return false;
  }

  public tryDodge(azrael: AzraelModel): boolean {
    if (this.stamina < 20 || azrael.isDodging || azrael.isDead) return false;
    this.stamina -= 20;
    this.staminaRegenDelay = 0.55;
    this.iFramesActive = true;
    this.iFramesTimer = 0.35; // 350ms of invulnerability
    azrael.isDodging = true;
    azrael.dodgeProgress = 0;
    soundEngine.playDodgeRoll();
    return true;
  }

  public executeAttack(
    isHeavy: boolean,
    azrael: AzraelModel,
    enemies: EnemyInstance[],
    boss: BossInstance | null,
    particles: ParticleSystem,
    stats: PlayerStats
  ): { embersGained: number; hitLanded: boolean } {
    if (azrael.isAttacking || azrael.isDodging || azrael.isDead) return { embersGained: 0, hitLanded: false };

    const staminaCost = isHeavy ? 30 : 16;
    if (this.stamina < staminaCost) {
      // Out of stamina penalty
      soundEngine.playSwordSwing(0.6);
      return { embersGained: 0, hitLanded: false };
    }

    this.stamina -= staminaCost;
    this.staminaRegenDelay = 0.7;

    const currentStep = isHeavy ? 1 : this.comboStep;
    azrael.triggerAttack(currentStep, isHeavy);

    // Audio SFX
    if (azrael.currentStance === 'executioner') {
      soundEngine.playGauntletPunch();
    } else if (isHeavy) {
      soundEngine.playHeavySlash();
    } else {
      soundEngine.playSwordSwing(1.0 + (currentStep - 1) * 0.15);
    }

    // Visual slash arc
    const slashColor = azrael.currentStance === 'wrath_unbound'
      ? 0x60a5fa
      : (azrael.currentStance === 'executioner' ? 0xf59e0b : 0x38bdf8);
    particles.spawnSlashArc(azrael.group.position, azrael.group.rotation, slashColor, isHeavy);

    // Base damage calculation based on stance and player strength
    let baseDamage = (isHeavy ? 65 : (28 + currentStep * 8)) + stats.strength * 3.5;
    if (azrael.currentStance === 'wrath_unbound') {
      baseDamage *= 1.6;
    } else if (azrael.currentStance === 'executioner') {
      baseDamage *= 1.25;
    }

    let hitLanded = false;
    let embersGained = 0;
    const playerPos = azrael.group.position;
    const playerForward = new THREE.Vector3(0, 0, 1).applyEuler(azrael.group.rotation);
    const attackRange = isHeavy ? 3.4 : (azrael.currentStance === 'executioner' ? 2.3 : 2.9);

    // 1. Check hits against standard enemies
    for (const enemy of enemies) {
      if (enemy.isDead) continue;
      const toEnemy = new THREE.Vector3().subVectors(enemy.group.position, playerPos);
      toEnemy.y = 0;
      const dist = toEnemy.length();

      if (dist <= attackRange) {
        toEnemy.normalize();
        const angle = playerForward.dot(toEnemy);
        // 120 degree frontal arc
        if (angle > 0.3 || dist <= 1.2) {
          hitLanded = true;
          const damage = Math.round(baseDamage * (0.9 + Math.random() * 0.2));
          enemy.takeDamage(damage);

          // Build wrath meter
          this.wrath = Math.min(this.maxWrath, this.wrath + (isHeavy ? 12 : 6));

          // Effects
          particles.spawnSparks(enemy.group.position, 16, slashColor);
          particles.spawnBlood(enemy.group.position, 12);
          soundEngine.playHitImpact(isHeavy);
          this.triggerHitstop(0.045);

          // Heavy knockback
          if (isHeavy) {
            enemy.group.position.addScaledVector(playerForward, 1.2);
            particles.spawnGroundShockwave(enemy.group.position, 2.8, slashColor);
          }

          if (enemy.isDead) {
            embersGained += enemy.stats.emberReward;
            soundEngine.playEnemyDeath();
          }
        }
      }
    }

    // 2. Check hit against Boss
    if (boss && !boss.isDead) {
      const toBoss = new THREE.Vector3().subVectors(boss.group.position, playerPos);
      toBoss.y = 0;
      const dist = toBoss.length();
      if (dist <= attackRange + 1.2) {
        hitLanded = true;
        const damage = Math.round(baseDamage * (0.85 + Math.random() * 0.3));
        boss.takeDamage(damage);

        this.wrath = Math.min(this.maxWrath, this.wrath + (isHeavy ? 15 : 8));
        particles.spawnSparks(boss.group.position, 25, slashColor);
        soundEngine.playHitImpact(isHeavy);
        this.triggerHitstop(0.05);

        if (isHeavy) {
          particles.spawnGroundShockwave(boss.group.position, 4.0, slashColor);
        }

        if (boss.isDead) {
          embersGained += 500 + boss.realmId * 250;
        }
      }
    }

    // Combo step progression
    if (!isHeavy) {
      this.comboStep = this.comboStep >= 3 ? 1 : this.comboStep + 1;
      this.comboTimer = 1.1; // 1.1s window to continue combo
    }

    return { embersGained, hitLanded };
  }

  public takePlayerDamage(amount: number, particles: ParticleSystem, azraelPos: THREE.Vector3): boolean {
    if (this.iFramesActive || this.health <= 0) {
      return false; // Dodged or already dead
    }

    this.health = Math.max(0, this.health - amount);
    particles.spawnBlood(azraelPos, 20);
    soundEngine.playHitImpact(true);
    this.triggerHitstop(0.06);

    return this.health <= 0;
  }

  public activateWrath(azrael: AzraelModel, particles: ParticleSystem): boolean {
    if (this.wrath < 50 || azrael.isDead) return false;
    this.wrath = 0;
    azrael.setStance('wrath_unbound');
    soundEngine.playWrathActivation();
    particles.spawnGroundShockwave(azrael.group.position, 6.0, 0x60a5fa);
    particles.spawnSparks(azrael.group.position, 40, 0x93c5fd);

    // Stance wears off after 15 seconds
    setTimeout(() => {
      if (!azrael.isDead && azrael.currentStance === 'wrath_unbound') {
        azrael.setStance('reaper');
      }
    }, 15000);

    return true;
  }

  private triggerHitstop(duration: number) {
    this.hitstopTimer = duration;
  }
}
