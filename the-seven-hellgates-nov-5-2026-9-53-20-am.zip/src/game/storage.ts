/**
 * The Seven Hellgates - Local Storage & Save System
 */

import { PlayerData } from './types';

const SAVE_KEY = 'seven_hellgates_save_v1';

export const INITIAL_PLAYER_DATA: PlayerData = {
  level: 1,
  embers: 0,
  unlockedRealms: [1], // Starts with Realm 1: Limbo
  currentRealm: 1,
  defeatedBosses: [],
  stats: {
    vitality: 10,
    vigor: 10,
    strength: 10,
    arcane: 10,
  },
  loreDiscovered: [],
};

export function loadPlayerData(): PlayerData {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return { ...INITIAL_PLAYER_DATA };
    const parsed = JSON.parse(raw);
    return {
      ...INITIAL_PLAYER_DATA,
      ...parsed,
      stats: {
        ...INITIAL_PLAYER_DATA.stats,
        ...(parsed.stats || {}),
      },
      unlockedRealms: Array.isArray(parsed.unlockedRealms) && parsed.unlockedRealms.length > 0
        ? parsed.unlockedRealms
        : [1],
      defeatedBosses: Array.isArray(parsed.defeatedBosses) ? parsed.defeatedBosses : [],
      loreDiscovered: Array.isArray(parsed.loreDiscovered) ? parsed.loreDiscovered : [],
    };
  } catch (e) {
    console.error('Failed to load save data, resetting to defaults:', e);
    return { ...INITIAL_PLAYER_DATA };
  }
}

export function savePlayerData(data: PlayerData): void {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save player data:', e);
  }
}

export function resetPlayerData(): PlayerData {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch (e) {
    console.error('Failed to clear save data:', e);
  }
  return { ...INITIAL_PLAYER_DATA };
}
