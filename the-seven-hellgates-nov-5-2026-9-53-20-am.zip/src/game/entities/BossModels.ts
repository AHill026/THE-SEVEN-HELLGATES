/**
 * The Seven Hellgates - Seven Major Boss Entities & The White-Eyed God
 * Towering 3D models with multi-phase mechanics, telegraphed special attacks,
 * and the mysterious secret climax reveal.
 */

import * as THREE from 'three';
import {
  createDemonicBeastTorso,
  createDemonicSkull,
  createAnatomicalLimb,
  createLoftedBodyGeometry,
} from './CharacterGeometry';

export interface BossAttackResult {
  damage: number;
  isShockwave: boolean;
  shockwavePos?: THREE.Vector3;
}

export class BossInstance {
  public id: string;
  public name: string;
  public realmId: number;
  public group: THREE.Group;
  public maxHealth: number;
  public currentHealth: number;
  public phase: number = 1;
  public isDead: boolean = false;
  public isAttacking: boolean = false;
  public currentAttackName: string = '';
  public attackTimer: number = 0;
  public cooldownTimer: number = 2.0;

  // Rig nodes
  private mainBody: THREE.Group;
  private head: THREE.Group;
  private weapon: THREE.Group | null = null;
  private leftArm: THREE.Group;
  private rightArm: THREE.Group;
  private auraLight: THREE.PointLight;
  private eyes: THREE.Mesh[] = [];

  constructor(realmId: number) {
    this.realmId = realmId;
    this.group = new THREE.Group();
    this.mainBody = new THREE.Group();
    this.group.add(this.mainBody);

    this.head = new THREE.Group();
    this.mainBody.add(this.head);

    this.leftArm = new THREE.Group();
    this.rightArm = new THREE.Group();
    this.mainBody.add(this.leftArm);
    this.mainBody.add(this.rightArm);

    this.id = `boss_realm_${realmId}`;
    this.name = this.getBossName(realmId);
    this.maxHealth = 800 + realmId * 250;
    this.currentHealth = this.maxHealth;

    this.auraLight = new THREE.PointLight(this.getBossAuraColor(realmId), 2.5, 12);
    this.auraLight.position.set(0, 3, 0);
    this.group.add(this.auraLight);

    this.buildBossModel(realmId);
  }

  private getBossName(realmId: number): string {
    switch (realmId) {
      case 1: return 'The Hollow King';
      case 2: return 'The Maw of Endless Hunger';
      case 3: return 'The Gilded Tyrant';
      case 4: return 'The Red Calamity';
      case 5: return 'The Saint of Ash';
      case 6: return 'The Butcher of Ruin';
      case 7: return 'The Sovereign of Desire';
      default: return 'Demonic Sovereign';
    }
  }

  private getBossAuraColor(realmId: number): number {
    switch (realmId) {
      case 1: return 0x38bdf8; // Limbo ice-blue
      case 2: return 0x84cc16; // Gluttony bile-green
      case 3: return 0xf59e0b; // Greed gold
      case 4: return 0xef4444; // Wrath hellfire
      case 5: return 0x64748b; // Heresy ashen gray
      case 6: return 0xb91c1c; // Violence blood crimson
      case 7: return 0xffffff; // Sovereign pure white
      default: return 0xef4444;
    }
  }

  private buildBossModel(realmId: number) {
    // Large intimidating scale (3.5m to 5m height)
    this.group.scale.set(1.5, 1.5, 1.5);

    if (realmId === 1) {
      // --- THE HOLLOW KING (Limbo Sovereign) ---
      // Towering skeletal monarch in ragged royal shroud, floating crown of thorns, death scythe
      const shroudMat = new THREE.MeshStandardMaterial({
        color: 0x0c0e14,
        roughness: 0.88,
      });
      const boneMat = new THREE.MeshStandardMaterial({
        color: 0x3d3832,
        roughness: 0.6,
        metalness: 0.2,
      });
      const crownMat = new THREE.MeshStandardMaterial({
        color: 0x222634,
        roughness: 0.3,
        metalness: 0.85,
      });
      const scytheMat = new THREE.MeshStandardMaterial({
        color: 0x1f2430,
        roughness: 0.25,
        metalness: 0.9,
      });
      const cyanEyeMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });

      // Torso & Flowing Ceremonial Shroud
      this.mainBody.position.y = 1.8;
      const shroudSlices = [
        { y: 0.8, rx: 0.38, rz: 0.28 },
        { y: 0.3, rx: 0.48, rz: 0.36 },
        { y: -0.4, rx: 0.65, rz: 0.48 },
        { y: -1.2, rx: 0.88, rz: 0.65 },
      ];
      const shroudGeom = createLoftedBodyGeometry(shroudSlices, 20, true, false);
      const shroud = new THREE.Mesh(shroudGeom, shroudMat);
      shroud.castShadow = true;
      this.mainBody.add(shroud);

      // Skeletal Ribcage & Spine
      for (let r = 0; r < 5; r++) {
        const rib = new THREE.Mesh(
          new THREE.TorusGeometry(0.36 - r * 0.03, 0.032, 6, 16, Math.PI * 1.3),
          boneMat
        );
        rib.rotation.x = Math.PI / 2;
        rib.position.set(0, 0.65 - r * 0.12, 0.05);
        this.mainBody.add(rib);
      }

      // Demonic Monarch Skull
      this.head.position.set(0, 1.35, 0.12);
      const skull = createDemonicSkull({ bone: boneMat, eye: cyanEyeMat });
      skull.scale.set(1.2, 1.2, 1.2);
      this.head.add(skull);

      // Floating Crown of Thorns with Dark Energy
      const crown = new THREE.Group();
      crown.position.set(0, 0.5, 0);
      const crownRing = new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.04, 8, 16), crownMat);
      crownRing.rotation.x = Math.PI / 2;
      crown.add(crownRing);

      for (let t = 0; t < 8; t++) {
        const thorn = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.22, 4), crownMat);
        const ang = (t / 8) * Math.PI * 2;
        thorn.position.set(Math.cos(ang) * 0.34, 0.1, Math.sin(ang) * 0.34);
        thorn.rotation.y = ang;
        crown.add(thorn);
      }
      this.head.add(crown);

      // Skeletal Arms & Spiked Bracers
      this.leftArm.position.set(0.68, 0.75, 0);
      const armGeomL = createAnatomicalLimb(0.12, 0.10, 0.08, 1.2);
      const armL = new THREE.Mesh(armGeomL, boneMat);
      armL.castShadow = true;
      this.leftArm.add(armL);

      this.rightArm.position.set(-0.68, 0.75, 0);
      const armGeomR = createAnatomicalLimb(0.12, 0.10, 0.08, 1.2);
      const armR = new THREE.Mesh(armGeomR, boneMat);
      armR.castShadow = true;
      this.rightArm.add(armR);

      // Great Death Scythe
      this.weapon = new THREE.Group();
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.045, 3.4), boneMat);
      this.weapon.add(shaft);

      const bladeGeom = new THREE.RingGeometry(1.0, 1.45, 20, 1, 0, Math.PI * 0.48);
      const blade = new THREE.Mesh(bladeGeom, scytheMat);
      blade.rotation.x = Math.PI / 2;
      blade.rotation.y = -Math.PI / 4;
      blade.position.set(0.65, 1.5, 0);
      blade.castShadow = true;
      this.weapon.add(blade);

      this.weapon.position.set(0, -0.6, 0.4);
      this.weapon.rotation.x = Math.PI / 2.5;
      this.rightArm.add(this.weapon);

    } else if (realmId === 3) {
      // --- THE GILDED TYRANT (Greed) ---
      // Heavy golden armored colossus with massive golden hammer
      const goldMat = new THREE.MeshStandardMaterial({
        color: 0xd4af37,
        roughness: 0.25,
        metalness: 0.95,
      });
      this.mainBody.position.y = 2.0;
      const plate = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.6, 0.9), goldMat);
      plate.castShadow = true;
      this.mainBody.add(plate);

      this.head.position.set(0, 1.1, 0);
      const helm = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.6, 0.6), goldMat);
      this.head.add(helm);

      this.weapon = new THREE.Group();
      const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 3.4), goldMat);
      this.weapon.add(handle);
      const hammerHead = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 1.4), goldMat);
      hammerHead.position.y = 1.3;
      hammerHead.castShadow = true;
      this.weapon.add(hammerHead);
      this.weapon.position.set(0, -0.6, 0.4);
      this.weapon.rotation.x = Math.PI / 2;
      this.rightArm.add(this.weapon);

    } else {
      // --- OTHER MAJOR BOSSES (Gluttony, Wrath, Heresy, Violence, Sovereign) ---
      const realmColors = [0x38bdf8, 0x65a30d, 0xf59e0b, 0xdc2626, 0x475569, 0x991b1b, 0xffffff];
      const bossCol = realmColors[(realmId - 1) % realmColors.length];
      const bossMat = new THREE.MeshStandardMaterial({
        color: bossCol,
        roughness: 0.4,
        metalness: 0.8,
      });

      this.mainBody.position.y = 1.9;
      const torsoMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.5, 2.0, 7), bossMat);
      torsoMesh.castShadow = true;
      this.mainBody.add(torsoMesh);

      this.head.position.set(0, 1.2, 0);
      const headMesh = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.6, 0.55), bossMat);
      headMesh.castShadow = true;
      this.head.add(headMesh);

      // Glowing Eyes
      const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), eyeMat);
      eyeL.position.set(0.16, 0.08, 0.3);
      this.head.add(eyeL);
      const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), eyeMat);
      eyeR.position.set(-0.16, 0.08, 0.3);
      this.head.add(eyeR);

      // Weapon
      this.weapon = new THREE.Group();
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.2, 3.0, 0.06), bossMat);
      blade.position.y = 1.2;
      blade.castShadow = true;
      this.weapon.add(blade);
      this.weapon.position.set(0, -0.6, 0.3);
      this.weapon.rotation.x = Math.PI / 2.2;
      this.rightArm.add(this.weapon);
    }
  }

  public takeDamage(amount: number) {
    if (this.isDead) return;
    this.currentHealth = Math.max(0, this.currentHealth - amount);

    // Phase 2 transition at 50% HP
    if (this.currentHealth <= this.maxHealth * 0.5 && this.phase === 1) {
      this.phase = 2;
      this.auraLight.intensity = 5.0; // Enrage glow!
    }

    if (this.currentHealth <= 0) {
      this.isDead = true;
      this.isAttacking = false;
    }
  }

  public update(delta: number, playerPos: THREE.Vector3): BossAttackResult {
    if (this.isDead) {
      this.group.position.y = Math.max(-2, this.group.position.y - delta * 0.9);
      this.group.rotation.x = THREE.MathUtils.lerp(this.group.rotation.x, -Math.PI / 2, delta * 3);
      return { damage: 0, isShockwave: false };
    }

    // Boss breathing and floating idle motion
    const time = Date.now() * 0.002;
    this.mainBody.position.y = (this.realmId === 1 ? 1.8 : 1.9) + Math.sin(time) * 0.12;

    // Face player
    const toPlayer = new THREE.Vector3().subVectors(playerPos, this.group.position);
    toPlayer.y = 0;
    const distance = toPlayer.length();
    if (distance > 0.01) {
      const angle = Math.atan2(toPlayer.x, toPlayer.z);
      this.group.rotation.y = THREE.MathUtils.damp(this.group.rotation.y, angle, 4.5, delta);
    }

    if (this.cooldownTimer > 0) {
      this.cooldownTimer -= delta;
    }

    // Boss Attack State Machine
    if (this.isAttacking) {
      this.attackTimer += delta * (this.phase === 2 ? 1.7 : 1.3);
      const p = this.attackTimer;
      let damageDealt = 0;
      let shockwaveTriggered = false;

      if (this.currentAttackName === 'scythe_sweep') {
        // Broad sweeping scythe attack
        if (p < 0.4) {
          // Telegraphed windup
          this.rightArm.rotation.set(-0.5, -1.2 * (p / 0.4), 0);
          this.mainBody.rotation.y = -0.5 * (p / 0.4);
        } else if (p < 0.75) {
          // Swift cleaving strike
          const t = (p - 0.4) / 0.35;
          this.rightArm.rotation.set(-0.3, THREE.MathUtils.lerp(-1.2, 1.4, t), 0);
          this.mainBody.rotation.y = THREE.MathUtils.lerp(-0.5, 0.6, t);
          if (p >= 0.55 && p - delta * 1.5 < 0.55 && distance <= 4.2) {
            damageDealt = 45;
          }
        } else {
          // Recovery
          this.rightArm.rotation.set(0, 0, 0);
          this.mainBody.rotation.y = 0;
        }
      } else {
        // Ground slam shockwave attack
        if (p < 0.5) {
          // Raise weapon high overhead
          const t = p / 0.5;
          this.rightArm.rotation.x = -Math.PI * 0.9 * t;
          this.leftArm.rotation.x = -Math.PI * 0.9 * t;
        } else if (p < 0.8) {
          // Slam to ground
          const t = (p - 0.5) / 0.3;
          this.rightArm.rotation.x = THREE.MathUtils.lerp(-Math.PI * 0.9, 0.8, t);
          this.leftArm.rotation.x = THREE.MathUtils.lerp(-Math.PI * 0.9, 0.8, t);
          if (p >= 0.65 && p - delta * 1.5 < 0.65) {
            shockwaveTriggered = true;
            if (distance <= 5.5) {
              damageDealt = 55;
            }
          }
        } else {
          // Recovery
          this.rightArm.rotation.x = 0;
          this.leftArm.rotation.x = 0;
        }
      }

      if (p >= 1.0) {
        this.isAttacking = false;
        this.attackTimer = 0;
        this.cooldownTimer = this.phase === 2 ? 1.4 : 2.4;
      }

      return {
        damage: damageDealt,
        isShockwave: shockwaveTriggered,
        shockwavePos: shockwaveTriggered ? this.group.position.clone() : undefined,
      };
    }

    // Approach or trigger attack
    if (distance > 3.8) {
      toPlayer.normalize();
      this.group.position.addScaledVector(toPlayer, (this.phase === 2 ? 3.6 : 2.5) * delta);
    } else if (this.cooldownTimer <= 0) {
      this.isAttacking = true;
      this.attackTimer = 0;
      this.currentAttackName = Math.random() > 0.4 ? 'scythe_sweep' : 'ground_slam';
    }

    return { damage: 0, isShockwave: false };
  }
}

/**
 * THE WHITE-EYED GOD
 * The climactic entity: Pitch darkness, two enormous glowing white eyes staring
 * directly through reality, with no face, no body, no silhouette.
 */
export class WhiteEyedGodEncounter {
  public group: THREE.Group;
  public eyeLeft: THREE.Mesh;
  public eyeRight: THREE.Mesh;
  public eyeLight: THREE.PointLight;
  private time: number = 0;

  constructor() {
    this.group = new THREE.Group();
    this.group.visible = false;

    // Pure brilliant white emissive eyes
    const eyeMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    });

    // Two enormous oval glowing eyes
    const eyeGeom = new THREE.SphereGeometry(1.2, 32, 16);
    eyeGeom.scale(1.0, 0.55, 0.3); // Slit/oval divine gaze

    this.eyeLeft = new THREE.Mesh(eyeGeom, eyeMat);
    this.eyeLeft.position.set(2.8, 6.0, -18);
    this.group.add(this.eyeLeft);

    this.eyeRight = new THREE.Mesh(eyeGeom, eyeMat);
    this.eyeRight.position.set(-2.8, 6.0, -18);
    this.group.add(this.eyeRight);

    // Eye glow halo
    this.eyeLight = new THREE.PointLight(0xffffff, 4.0, 45);
    this.eyeLight.position.set(0, 6.0, -15);
    this.group.add(this.eyeLight);
  }

  public update(delta: number) {
    this.time += delta;
    // Slow ominous divine gaze pulsation
    const intensity = 3.5 + Math.sin(this.time * 1.8) * 0.8;
    this.eyeLight.intensity = intensity;

    const scaleMod = 1.0 + Math.sin(this.time * 1.2) * 0.05;
    this.eyeLeft.scale.set(scaleMod, scaleMod * 0.55, 0.3);
    this.eyeRight.scale.set(scaleMod, scaleMod * 0.55, 0.3);
  }
}
