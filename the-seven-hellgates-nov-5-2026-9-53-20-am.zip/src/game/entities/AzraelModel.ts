/**
 * The Seven Hellgates - Azrael 3D Model & Kinematics
 * Fully modeled to match the dark-fantasy reference:
 * - Blackened Damascus steel gothic armor with fluted ridges
 * - Layered dark cowl/scarf wrapped around neck & shoulders
 * - Criss-crossing leather harness straps with silver buckles
 * - Multi-tiered spiked gothic pauldrons on both shoulders
 * - Crimson tattered sash/tabard hanging between leg faulds
 * - Multi-segment shredded battle cape with back silver filigree spine clasp
 * - Shaggy dark hair with pale-blue supernatural glowing eyes
 * - Executioner greatsword with cyan glowing occult runes down central fuller
 */

import * as THREE from 'three';
import { CombatStance } from '../types';
import { materialFactory } from '../vfx/MaterialFactory';
import {
  createAthleticHumanoidTorso,
  createFittedCuirass,
  createSculptedHead,
  createAnatomicalLimb,
  createArticulatedHand,
  createGothicSabatonFoot,
  createTieredGothicPauldron,
  createExecutionerGreatsword,
} from './CharacterGeometry';
import { glbLoaderService } from '../loaders/GLBModelLoader';

export class AzraelModel {
  public group: THREE.Group;

  // Articulated joints
  private rootJoint: THREE.Group;
  private pelvis: THREE.Group;
  private spine: THREE.Group;
  private chest: THREE.Group;
  private neck: THREE.Group;
  private head: THREE.Group;
  
  private leftShoulder: THREE.Group;
  private leftArm: THREE.Group;
  private leftForearm: THREE.Group;
  private leftHand: THREE.Group;

  private rightShoulder: THREE.Group;
  private rightArm: THREE.Group;
  private rightForearm: THREE.Group;
  private rightHand: THREE.Group;

  private leftThigh: THREE.Group;
  private leftShin: THREE.Group;
  private leftFoot: THREE.Group;

  private rightThigh: THREE.Group;
  private rightShin: THREE.Group;
  private rightFoot: THREE.Group;

  private capeGroup: THREE.Group;
  private capeSegments: THREE.Mesh[] = [];
  private frontSash: THREE.Mesh;

  // Weapons & FX
  private greatsword: THREE.Group;
  private swordRuneLight: THREE.PointLight;
  private eyeGlowLight: THREE.PointLight;
  private wrathAuraGroup: THREE.Group;

  // State
  public currentAnim: string = 'idle';
  private animTime: number = 0;
  private attackPhase: number = 0;
  public isAttacking: boolean = false;
  public isDodging: boolean = false;
  public dodgeProgress: number = 0;
  public isDead: boolean = false;
  public deathProgress: number = 0;
  public currentStance: CombatStance = 'reaper';
  public onFootstep?: (isSprinting: boolean) => void;
  private lastStepSide: number = 0;

  constructor() {
    this.group = new THREE.Group();

    // Procedural PBR materials from MaterialFactory
    const damascusSteel = materialFactory.createDamascusSteel();
    const limbPlate = materialFactory.createGothicLimbPlate();
    const gothicSilver = materialFactory.createGothicSilver();
    const pauldronBlackenedSteel = materialFactory.createPauldronBlackenedSteel();
    const pauldronWornTrim = materialFactory.createPauldronWornTrim();
    const weatheredLeather = materialFactory.createWeatheredLeather();
    const crimsonSashMat = materialFactory.createCrimsonSash();
    const tatteredCloth = materialFactory.createTatteredCloth();
    const swordBladeMat = materialFactory.createSwordBladeSteel();
    const runeGlowMat = materialFactory.createRunicGlowMaterial();
    const eyeMat = materialFactory.createGlowingEyes();
    const skinMat = materialFactory.createAzraelSkin();
    const scarMat = materialFactory.createBattleScar();
    const hairMat = materialFactory.createDarkHair();

    // --- SKELETAL RIG HIERARCHY ---
    this.rootJoint = new THREE.Group();
    this.group.add(this.rootJoint);

    // 1. Pelvis & Articulated Faulds
    this.pelvis = new THREE.Group();
    this.pelvis.position.y = 1.05;
    this.rootJoint.add(this.pelvis);

    // Anatomical pelvic girdle & glutes base
    const pelvisGeom = createAnatomicalLimb(0.20, 0.22, 0.19, 0.24, 0.03, 0.02);
    const pelvisMesh = new THREE.Mesh(pelvisGeom, damascusSteel);
    pelvisMesh.position.y = 0.12;
    pelvisMesh.castShadow = true;
    this.pelvis.add(pelvisMesh);

    // Leather belt with sculpted gothic silver buckle
    const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.23, 0.22, 0.07, 16), weatheredLeather);
    belt.position.y = 0.1;
    this.pelvis.add(belt);
    const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.10, 0.25), gothicSilver);
    buckle.position.set(0, 0.1, 0.12);
    this.pelvis.add(buckle);

    // Crimson Tattered Front Sash (hanging between thighs as in reference image)
    const sashGeom = new THREE.PlaneGeometry(0.22, 0.48, 3, 5);
    this.frontSash = new THREE.Mesh(sashGeom, crimsonSashMat);
    this.frontSash.position.set(0, -0.22, 0.16);
    this.frontSash.castShadow = true;
    this.pelvis.add(this.frontSash);

    // Anatomical Side Hip Tassets conforming to thighs
    for (let s = -1; s <= 1; s += 2) {
      const tasset = new THREE.Mesh(
        new THREE.CylinderGeometry(0.13, 0.15, 0.32, 8, 1, true, 0, Math.PI),
        limbPlate
      );
      tasset.position.set(s * 0.24, -0.08, 0);
      tasset.rotation.z = -s * 0.18;
      tasset.rotation.y = s * 0.4;
      tasset.castShadow = true;
      this.pelvis.add(tasset);
    }

    // 2. Spine & Chest (Muscular Humanoid Torso + Fitted Gothic Cuirass)
    this.spine = new THREE.Group();
    this.spine.position.y = 0.18;
    this.pelvis.add(this.spine);

    this.chest = new THREE.Group();
    this.chest.position.y = 0.26;
    this.spine.add(this.chest);

    // Muscular athletic humanoid torso base
    const torsoMesh = new THREE.Mesh(createAthleticHumanoidTorso(), skinMat);
    torsoMesh.position.y = 0.08;
    torsoMesh.castShadow = true;
    this.chest.add(torsoMesh);

    // Fitted gothic Damascus steel cuirass with central tapul ridge and fauld lames
    const cuirass = new THREE.Mesh(createFittedCuirass(), damascusSteel);
    cuirass.position.y = 0.08;
    cuirass.castShadow = true;
    this.chest.add(cuirass);

    // Fluted gothic center ridge (tapul)
    const tapulRidge = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.38, 4), gothicSilver);
    tapulRidge.rotation.x = -0.15;
    tapulRidge.position.set(0, 0.12, 0.22);
    this.chest.add(tapulRidge);

    // Criss-crossing Leather Harness Straps over chest
    const strap1 = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.04, 0.38), weatheredLeather);
    strap1.rotation.z = 0.52;
    strap1.position.y = 0.08;
    this.chest.add(strap1);

    const strap2 = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.04, 0.38), weatheredLeather);
    strap2.rotation.z = -0.52;
    strap2.position.y = 0.08;
    this.chest.add(strap2);

    // 3. Layered Dark Cowl / Hood Draped Around Neck & Shoulders (Exact reference match)
    const cowlRing1 = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.10, 10, 20), tatteredCloth);
    cowlRing1.rotation.x = Math.PI / 2 + 0.15;
    cowlRing1.position.set(0, 0.32, 0.04);
    cowlRing1.castShadow = true;
    this.chest.add(cowlRing1);

    const cowlRing2 = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.09, 10, 20), tatteredCloth);
    cowlRing2.rotation.x = Math.PI / 2 + 0.28;
    cowlRing2.position.set(0, 0.24, 0.06);
    cowlRing2.castShadow = true;
    this.chest.add(cowlRing2);

    // 4. Head, Face, Battle Scars & Glowing Pale-Blue Eyes
    this.neck = new THREE.Group();
    this.neck.position.y = 0.34;
    this.chest.add(this.neck);

    const neckGeom = new THREE.CylinderGeometry(0.09, 0.11, 0.16, 12);
    const neckMesh = new THREE.Mesh(neckGeom, skinMat);
    neckMesh.position.y = 0.06;
    this.neck.add(neckMesh);

    this.head = new THREE.Group();
    this.head.position.y = 0.15;
    this.neck.add(this.head);

    // Sculpted anatomical head with defined jawline, chin, and brow
    const face = new THREE.Mesh(createSculptedHead(), skinMat);
    face.position.y = 0.02;
    face.castShadow = true;
    this.head.add(face);

    // Visible Battle Scar across right eye and cheekbone (crimson scarred tissue)
    const scarCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.048, 0.085, 0.12),
      new THREE.Vector3(0.058, 0.035, 0.13),
      new THREE.Vector3(0.068, -0.045, 0.115),
    ]);
    const scarGeom = new THREE.TubeGeometry(scarCurve, 8, 0.006, 4, false);
    const scarMesh = new THREE.Mesh(scarGeom, scarMat);
    this.head.add(scarMesh);

    // Defined 3D Nose Bridge
    const noseGeom = new THREE.ConeGeometry(0.02, 0.08, 4);
    const noseMesh = new THREE.Mesh(noseGeom, skinMat);
    noseMesh.rotation.set(0.24, 0, 0);
    noseMesh.position.set(0, 0.025, 0.142);
    this.head.add(noseMesh);

    // Sculpted Dark Eyebrows framing brow ridge
    const browGeomL = new THREE.BoxGeometry(0.045, 0.012, 0.02);
    const browL = new THREE.Mesh(browGeomL, hairMat);
    browL.rotation.z = -0.12;
    browL.position.set(0.052, 0.062, 0.13);
    this.head.add(browL);

    const browGeomR = new THREE.BoxGeometry(0.045, 0.012, 0.02);
    const browR = new THREE.Mesh(browGeomR, hairMat);
    browR.rotation.z = 0.12;
    browR.position.set(-0.052, 0.062, 0.13);
    this.head.add(browR);

    // Sculpted Layered Dark Hair (Shaggy bangs framing face and temples as in reference)
    const hairTop = new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 10), hairMat);
    hairTop.position.set(0, 0.12, -0.02);
    hairTop.scale.set(1.05, 0.95, 1.15);
    this.head.add(hairTop);

    // Front swept bangs
    const bangConfigs = [
      { x: 0.07, y: 0.07, z: 0.125, rz: -0.38, rx: 0.35, scale: 0.9 },
      { x: -0.07, y: 0.07, z: 0.125, rz: 0.38, rx: 0.35, scale: 0.9 },
      { x: 0.02, y: 0.09, z: 0.13, rz: -0.15, rx: 0.4, scale: 0.8 },
      { x: 0.11, y: 0.02, z: 0.09, rz: -0.55, rx: 0.2, scale: 1.1 },
      { x: -0.11, y: 0.02, z: 0.09, rz: 0.55, rx: 0.2, scale: 1.1 },
    ];
    bangConfigs.forEach((cfg) => {
      const bang = new THREE.Mesh(new THREE.ConeGeometry(0.045 * cfg.scale, 0.19 * cfg.scale, 4), hairMat);
      bang.rotation.set(cfg.rx, 0, cfg.rz);
      bang.position.set(cfg.x, cfg.y, cfg.z);
      this.head.add(bang);
    });

    // Glowing Supernatural Pale-Blue Almond Eyes (restrained emissive)
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.024, 8, 8), eyeMat);
    eyeL.position.set(0.055, 0.04, 0.125);
    this.head.add(eyeL);

    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.024, 8, 8), eyeMat);
    eyeR.position.set(-0.055, 0.04, 0.125);
    this.head.add(eyeR);

    // Restrained supernatural eye glow light to prevent blooming over face features
    this.eyeGlowLight = new THREE.PointLight(0x38bdf8, 0.45, 2.0);
    this.eyeGlowLight.position.set(0, 0.04, 0.20);
    this.head.add(this.eyeGlowLight);

    // 5. Multi-Tier Spiked Gothic Pauldrons on Shoulders
    // Left Shoulder & Articulated Arm
    this.leftShoulder = new THREE.Group();
    this.leftShoulder.position.set(0.34, 0.26, 0);
    this.chest.add(this.leftShoulder);

    // Anatomical deltoid muscle cap beneath pauldron bridging chest to bicep
    const deltoidL = new THREE.Mesh(createAnatomicalLimb(0.105, 0.098, 0.09, 0.18, 0.02, 0.02), weatheredLeather);
    deltoidL.position.set(0, -0.04, 0);
    deltoidL.castShadow = true;
    this.leftShoulder.add(deltoidL);

    const pauldronL = createTieredGothicPauldron(false, pauldronBlackenedSteel, pauldronWornTrim);
    this.leftShoulder.add(pauldronL);

    this.leftArm = new THREE.Group();
    this.leftShoulder.add(this.leftArm);

    // Muscular bicep & tricep
    const bicepGeomL = createAnatomicalLimb(0.09, 0.085, 0.075, 0.28, 0.02, 0.015);
    const bicepL = new THREE.Mesh(bicepGeomL, weatheredLeather);
    bicepL.position.y = 0;
    bicepL.castShadow = true;
    this.leftArm.add(bicepL);

    this.leftForearm = new THREE.Group();
    this.leftForearm.position.y = -0.28;
    this.leftArm.add(this.leftForearm);

    // Fluted Damascus Vambrace with couter elbow spike
    const vambraceGeomL = createAnatomicalLimb(0.095, 0.085, 0.07, 0.28, 0.02);
    const vambraceL = new THREE.Mesh(vambraceGeomL, limbPlate);
    vambraceL.castShadow = true;
    this.leftForearm.add(vambraceL);

    const elbowSpikeL = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 4), gothicSilver);
    elbowSpikeL.rotation.x = Math.PI / 2;
    elbowSpikeL.position.set(0, -0.05, -0.1);
    this.leftForearm.add(elbowSpikeL);

    this.leftHand = new THREE.Group();
    this.leftHand.position.y = -0.28;
    this.leftForearm.add(this.leftHand);

    // Complete articulated hand with palm and fingers
    const handL = createArticulatedHand(false, gothicSilver);
    this.leftHand.add(handL);

    // Right Shoulder & Articulated Arm
    this.rightShoulder = new THREE.Group();
    this.rightShoulder.position.set(-0.34, 0.26, 0);
    this.chest.add(this.rightShoulder);

    // Anatomical deltoid muscle cap beneath pauldron bridging chest to bicep
    const deltoidR = new THREE.Mesh(createAnatomicalLimb(0.105, 0.098, 0.09, 0.18, 0.02, 0.02), weatheredLeather);
    deltoidR.position.set(0, -0.04, 0);
    deltoidR.castShadow = true;
    this.rightShoulder.add(deltoidR);

    const pauldronR = createTieredGothicPauldron(true, pauldronBlackenedSteel, pauldronWornTrim);
    this.rightShoulder.add(pauldronR);

    this.rightArm = new THREE.Group();
    this.rightShoulder.add(this.rightArm);

    const bicepGeomR = createAnatomicalLimb(0.09, 0.085, 0.075, 0.28, 0.02, 0.015);
    const bicepR = new THREE.Mesh(bicepGeomR, weatheredLeather);
    bicepR.position.y = 0;
    bicepR.castShadow = true;
    this.rightArm.add(bicepR);

    this.rightForearm = new THREE.Group();
    this.rightForearm.position.y = -0.28;
    this.rightArm.add(this.rightForearm);

    const vambraceGeomR = createAnatomicalLimb(0.095, 0.085, 0.07, 0.28, 0.02);
    const vambraceR = new THREE.Mesh(vambraceGeomR, limbPlate);
    vambraceR.castShadow = true;
    this.rightForearm.add(vambraceR);

    const elbowSpikeR = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 4), gothicSilver);
    elbowSpikeR.rotation.x = Math.PI / 2;
    elbowSpikeR.position.set(0, -0.05, -0.1);
    this.rightForearm.add(elbowSpikeR);

    this.rightHand = new THREE.Group();
    this.rightHand.position.y = -0.28;
    this.rightForearm.add(this.rightHand);

    const handR = createArticulatedHand(true, gothicSilver);
    this.rightHand.add(handR);

    // 6. Muscular Anatomical Legs, Greaves & Gothic Sabatons
    // Left Leg
    this.leftThigh = new THREE.Group();
    this.leftThigh.position.set(0.18, -0.08, 0);
    this.pelvis.add(this.leftThigh);

    const thighGeomL = createAnatomicalLimb(0.13, 0.115, 0.095, 0.44, 0.035, 0.02);
    const cuisseL = new THREE.Mesh(thighGeomL, limbPlate);
    cuisseL.castShadow = true;
    this.leftThigh.add(cuisseL);

    this.leftShin = new THREE.Group();
    this.leftShin.position.y = -0.44;
    this.leftThigh.add(this.leftShin);

    // Articulated Gothic Knee Cop (Poleyn) with point
    const kneeL = new THREE.Mesh(new THREE.ConeGeometry(0.075, 0.15, 4), gothicSilver);
    kneeL.rotation.x = -Math.PI / 2;
    kneeL.position.set(0, 0, 0.12);
    this.leftShin.add(kneeL);

    const calfGeomL = createAnatomicalLimb(0.115, 0.10, 0.08, 0.44, 0.03, 0.015);
    const greaveL = new THREE.Mesh(calfGeomL, limbPlate);
    greaveL.castShadow = true;
    this.leftShin.add(greaveL);

    this.leftFoot = new THREE.Group();
    this.leftFoot.position.y = -0.44;
    this.leftShin.add(this.leftFoot);

    // Sculpted pointed gothic sabaton with articulated lames & spur
    const sabatonL = createGothicSabatonFoot(limbPlate, gothicSilver);
    this.leftFoot.add(sabatonL);

    // Right Leg
    this.rightThigh = new THREE.Group();
    this.rightThigh.position.set(-0.18, -0.08, 0);
    this.pelvis.add(this.rightThigh);

    const thighGeomR = createAnatomicalLimb(0.13, 0.115, 0.095, 0.44, 0.035, 0.02);
    const cuisseR = new THREE.Mesh(thighGeomR, limbPlate);
    cuisseR.castShadow = true;
    this.rightThigh.add(cuisseR);

    this.rightShin = new THREE.Group();
    this.rightShin.position.y = -0.44;
    this.rightThigh.add(this.rightShin);

    const kneeR = new THREE.Mesh(new THREE.ConeGeometry(0.075, 0.15, 4), gothicSilver);
    kneeR.rotation.x = -Math.PI / 2;
    kneeR.position.set(0, 0, 0.12);
    this.rightShin.add(kneeR);

    const calfGeomR = createAnatomicalLimb(0.115, 0.10, 0.08, 0.44, 0.03, 0.015);
    const greaveR = new THREE.Mesh(calfGeomR, limbPlate);
    greaveR.castShadow = true;
    this.rightShin.add(greaveR);

    this.rightFoot = new THREE.Group();
    this.rightFoot.position.y = -0.44;
    this.rightShin.add(this.rightFoot);

    const sabatonR = createGothicSabatonFoot(limbPlate, gothicSilver);
    this.rightFoot.add(sabatonR);

    // 7. Back: Ornate Silver Spine Clasp & Shredded Cape (Matching Reference Back View)
    const spineClasp = new THREE.Group();
    spineClasp.position.set(0, 0.15, -0.18);
    const vertBar = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.45, 0.04), gothicSilver);
    const horizBar = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.05, 0.04), gothicSilver);
    horizBar.position.y = 0.08;
    spineClasp.add(vertBar);
    spineClasp.add(horizBar);
    this.chest.add(spineClasp);

    // Articulated Shredded Cape Segments
    this.capeGroup = new THREE.Group();
    this.capeGroup.position.set(0, 0.18, -0.19);
    this.chest.add(this.capeGroup);

    let parentCapeNode: THREE.Group = this.capeGroup;
    for (let i = 0; i < 4; i++) {
      const nextCapeNode = new THREE.Group();
      nextCapeNode.position.y = -0.28;
      parentCapeNode.add(nextCapeNode);

      const segment = new THREE.Mesh(
        new THREE.PlaneGeometry(0.52 - i * 0.05, 0.3, 4, 1),
        tatteredCloth
      );
      segment.position.y = -0.15;
      segment.castShadow = true;
      nextCapeNode.add(segment);
      this.capeSegments.push(segment);

      parentCapeNode = nextCapeNode;
    }

    // 8. Executioner Greatsword with Cyan Runic Fuller (Matching Reference Image)
    const swordResult = createExecutionerGreatsword(swordBladeMat, runeGlowMat, gothicSilver, weatheredLeather);
    this.greatsword = swordResult.swordGroup;
    this.swordRuneLight = swordResult.runeLight;

    // Attach greatsword to right hand
    this.rightHand.add(this.greatsword);
    this.greatsword.position.set(0, -0.05, 0.06);
    this.greatsword.rotation.set(Math.PI / 2, 0, 0);

    // 9. Wrath Unbound Supernatural Awakening Rings
    this.wrathAuraGroup = new THREE.Group();
    for (let i = 0; i < 8; i++) {
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.4 + i * 0.14, 0.52 + i * 0.14, 20),
        new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.4,
          blending: THREE.AdditiveBlending,
        })
      );
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = 0.2 + i * 0.24;
      this.wrathAuraGroup.add(ring);
    }
    this.wrathAuraGroup.visible = false;
    this.group.add(this.wrathAuraGroup);
  }

  public setStance(stance: CombatStance) {
    this.currentStance = stance;
    if (stance === 'executioner') {
      // Greatsword sheathed on back, fists forward
      this.chest.add(this.greatsword);
      this.greatsword.position.set(0.12, 0.1, -0.24);
      this.greatsword.rotation.set(-0.35, 0.2, -2.4);
      this.wrathAuraGroup.visible = false;
    } else if (stance === 'wrath_unbound') {
      this.rightHand.add(this.greatsword);
      this.greatsword.position.set(0, -0.05, 0.06);
      this.greatsword.rotation.set(Math.PI / 2, 0, 0);
      this.wrathAuraGroup.visible = true;
      this.swordRuneLight.intensity = 1.4;
    } else {
      // Reaper stance (Greatsword held)
      this.rightHand.add(this.greatsword);
      this.greatsword.position.set(0, -0.05, 0.06);
      this.greatsword.rotation.set(Math.PI / 2, 0, 0);
      this.wrathAuraGroup.visible = false;
      this.swordRuneLight.intensity = 0.75;
    }
  }

  public update(delta: number, isMoving: boolean, isSprinting: boolean) {
    this.animTime += delta;

    // Restrained, atmospheric glowing supernatural eyes and sword runes (preserves surface details without glare)
    const eyePulse = 0.38 + Math.sin(this.animTime * 3.8) * 0.07;
    this.eyeGlowLight.intensity = eyePulse * (this.currentStance === 'wrath_unbound' ? 1.8 : 1.0);
    this.swordRuneLight.intensity = (0.65 + Math.sin(this.animTime * 4.5) * 0.12) * (this.currentStance === 'wrath_unbound' ? 1.6 : 1.0);

    // Front crimson sash secondary sway
    this.frontSash.rotation.x = Math.sin(this.animTime * 5) * 0.12 + (isMoving ? 0.3 : 0.05);

    if (this.currentStance === 'wrath_unbound') {
      this.wrathAuraGroup.rotation.y += delta * 3.0;
      this.wrathAuraGroup.children.forEach((c, i) => {
        c.scale.setScalar(1 + Math.sin(this.animTime * 5 + i) * 0.18);
      });
    }

    // 1. Death Animation
    if (this.isDead) {
      this.deathProgress = Math.min(1, this.deathProgress + delta * 1.5);
      this.rootJoint.position.y = THREE.MathUtils.lerp(0, -0.85, this.deathProgress);
      this.rootJoint.rotation.x = THREE.MathUtils.lerp(0, -Math.PI / 2.2, this.deathProgress);
      return;
    }

    // 2. Dodge Roll
    if (this.isDodging) {
      this.dodgeProgress += delta * 2.8;
      const p = Math.min(1, this.dodgeProgress);
      this.rootJoint.position.y = -Math.sin(p * Math.PI) * 0.65;
      this.rootJoint.rotation.x = p * Math.PI * 2;
      this.spine.rotation.x = 0.8;
      this.leftThigh.rotation.x = -1.2;
      this.rightThigh.rotation.x = -1.2;
      this.leftShin.rotation.x = 1.5;
      this.rightShin.rotation.x = 1.5;

      if (p >= 1) {
        this.isDodging = false;
        this.dodgeProgress = 0;
        this.rootJoint.position.y = 0;
        this.rootJoint.rotation.x = 0;
      }
      return;
    }

    // 3. Attack Animations
    if (this.isAttacking) {
      this.updateAttackAnimation(delta);
      return;
    }

    // 4. Locomotion / Idle
    if (isMoving) {
      const speed = isSprinting ? 9.5 : 6.0;
      const legFreq = this.animTime * speed;
      const legAmp = isSprinting ? 0.75 : 0.5;

      // Stride-synchronized footstep detection (left / right foot ground strikes)
      const sinVal = Math.sin(legFreq);
      if (sinVal > 0.82 && this.lastStepSide !== 1) {
        this.lastStepSide = 1;
        this.onFootstep?.(isSprinting);
      } else if (sinVal < -0.82 && this.lastStepSide !== -1) {
        this.lastStepSide = -1;
        this.onFootstep?.(isSprinting);
      }

      this.rootJoint.position.y = Math.abs(Math.sin(legFreq)) * 0.08;

      this.leftThigh.rotation.x = Math.sin(legFreq) * legAmp;
      this.rightThigh.rotation.x = -Math.sin(legFreq) * legAmp;
      this.leftShin.rotation.x = Math.max(0, -Math.sin(legFreq) * legAmp * 1.2);
      this.rightShin.rotation.x = Math.max(0, Math.sin(legFreq) * legAmp * 1.2);

      this.spine.rotation.x = isSprinting ? 0.28 : 0.12;
      this.chest.rotation.y = -Math.sin(legFreq) * 0.15;

      if (this.currentStance === 'executioner') {
        this.leftShoulder.rotation.x = -Math.sin(legFreq) * legAmp;
        this.rightShoulder.rotation.x = Math.sin(legFreq) * legAmp;
      } else {
        this.rightShoulder.rotation.x = -0.4 + Math.sin(legFreq) * 0.15;
        this.leftShoulder.rotation.x = 0.3 - Math.sin(legFreq) * 0.15;
      }

      this.capeGroup.rotation.x = (isSprinting ? 0.7 : 0.4) + Math.sin(this.animTime * 14) * 0.15;
    } else {
      this.lastStepSide = 0;
      // Idle Breathing
      const breath = Math.sin(this.animTime * 2.2);
      this.rootJoint.position.y = 0;
      this.chest.position.y = 0.26 + breath * 0.015;
      this.chest.rotation.x = breath * 0.02;
      this.head.rotation.x = -breath * 0.015;

      this.leftThigh.rotation.set(0, 0, 0);
      this.rightThigh.rotation.set(0, 0, 0);
      this.leftShin.rotation.set(0, 0, 0);
      this.rightShin.rotation.set(0, 0, 0);

      if (this.currentStance === 'executioner') {
        this.leftShoulder.rotation.set(-0.8, 0.4, 0.2);
        this.rightShoulder.rotation.set(-0.7, -0.4, -0.2);
        this.leftForearm.rotation.set(-1.0, 0, 0);
        this.rightForearm.rotation.set(-1.0, 0, 0);
      } else {
        this.rightShoulder.rotation.set(-0.5 + breath * 0.02, -0.2, 0.1);
        this.rightForearm.rotation.set(-0.6, 0.1, 0);
        this.leftShoulder.rotation.set(-0.3, 0.3, 0);
        this.leftForearm.rotation.set(-0.4, 0, 0);
      }

      this.capeGroup.rotation.x = 0.12 + Math.sin(this.animTime * 1.5) * 0.05;
    }
  }

  public triggerAttack(comboStep: number, isHeavy: boolean) {
    this.isAttacking = true;
    this.attackPhase = 0;
    this.currentAnim = isHeavy ? 'heavy' : `light_${comboStep}`;
  }

  private updateAttackAnimation(delta: number) {
    this.attackPhase += delta * 3.8;
    const p = Math.min(1, this.attackPhase);

    if (this.currentAnim === 'heavy') {
      if (p < 0.4) {
        const t = p / 0.4;
        this.spine.rotation.x = -0.3 * t;
        this.rightShoulder.rotation.set(-Math.PI * 0.85 * t, 0, 0.3 * t);
        this.leftShoulder.rotation.set(-Math.PI * 0.8 * t, 0, -0.3 * t);
      } else if (p < 0.7) {
        const t = (p - 0.4) / 0.3;
        this.spine.rotation.x = THREE.MathUtils.lerp(-0.3, 0.5, t);
        this.rightShoulder.rotation.set(THREE.MathUtils.lerp(-Math.PI * 0.85, 0.8, t), 0, 0);
        this.leftShoulder.rotation.set(THREE.MathUtils.lerp(-Math.PI * 0.8, 0.7, t), 0, 0);
      } else {
        const t = (p - 0.7) / 0.3;
        this.spine.rotation.x = THREE.MathUtils.lerp(0.5, 0, t);
        this.rightShoulder.rotation.set(THREE.MathUtils.lerp(0.8, -0.5, t), 0, 0);
      }
    } else if (this.currentAnim === 'light_1') {
      if (p < 0.4) {
        this.chest.rotation.y = -0.8 * (p / 0.4);
        this.rightShoulder.rotation.set(-0.6, -0.8, 0);
      } else if (p < 0.7) {
        const t = (p - 0.4) / 0.3;
        this.chest.rotation.y = THREE.MathUtils.lerp(-0.8, 0.9, t);
        this.rightShoulder.rotation.set(-0.4, 0.8, 0);
      } else {
        const t = (p - 0.7) / 0.3;
        this.chest.rotation.y = THREE.MathUtils.lerp(0.9, 0, t);
      }
    } else if (this.currentAnim === 'light_2') {
      if (p < 0.4) {
        this.chest.rotation.y = 0.6 * (p / 0.4);
        this.rightShoulder.rotation.set(0.4, 0.5, 0);
      } else if (p < 0.7) {
        const t = (p - 0.4) / 0.3;
        this.chest.rotation.y = THREE.MathUtils.lerp(0.6, -0.7, t);
        this.rightShoulder.rotation.set(THREE.MathUtils.lerp(0.4, -1.2, t), -0.6, 0);
      } else {
        const t = (p - 0.7) / 0.3;
        this.chest.rotation.y = THREE.MathUtils.lerp(-0.7, 0, t);
      }
    } else {
      const t = p;
      this.rootJoint.rotation.y = t * Math.PI * 2;
      this.rightShoulder.rotation.set(-0.6, 0.4, 0);
    }

    if (p >= 1) {
      this.isAttacking = false;
      this.rootJoint.rotation.y = 0;
      this.spine.rotation.set(0, 0, 0);
      this.chest.rotation.set(0, 0, 0);
    }
  }

  /**
   * Supports loading external GLB models with embedded materials, textures, and animation clips
   */
  public async loadExternalGLB(url: string): Promise<boolean> {
    try {
      const gltf = await glbLoaderService.loadModel(url);
      const instance = glbLoaderService.createCharacterInstance(gltf);
      this.rootJoint.visible = false;
      this.group.add(instance.group);
      return true;
    } catch (e) {
      console.warn('Could not load external GLB for Azrael:', e);
      return false;
    }
  }
}
