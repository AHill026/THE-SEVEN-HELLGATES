/**
 * The Seven Hellgates - Procedural Anatomical Character Geometry
 * Generates continuous, anatomical humanoid and demonic creature geometry
 * with sculpted musculature, facial features, fitted gothic armor,
 * digitigrade demon limbs, articulated hands, and executioner greatsword.
 */

import * as THREE from 'three';

export interface LoftedSlice {
  y: number;
  rx: number;
  rz: number;
  cx?: number;
  cz?: number;
  bulgeZFront?: number;
  bulgeXSide?: number;
  indentZBack?: number;
}

/**
 * Generates a smooth, seamless lofted organic BufferGeometry from cross-sectional anatomical slices
 */
export function createLoftedBodyGeometry(
  slices: LoftedSlice[],
  radialSegments: number = 20,
  closeTop: boolean = false,
  closeBottom: boolean = false
): THREE.BufferGeometry {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let j = 0; j < slices.length; j++) {
    const s = slices[j];
    const v = j / (slices.length - 1);
    const cx = s.cx || 0;
    const cz = s.cz || 0;
    const rx = s.rx;
    const rz = s.rz;
    const bzf = s.bulgeZFront || 0;
    const bxs = s.bulgeXSide || 0;
    const izb = s.indentZBack || 0;

    for (let i = 0; i <= radialSegments; i++) {
      const u = i / radialSegments;
      const angle = u * Math.PI * 2;
      const cosA = Math.cos(angle);
      const sinA = Math.sin(angle);

      // Anatomical shaping: forward pectoral/belly bulge, latissimus side flare, spine groove
      let curRx = rx;
      if (bxs !== 0 && Math.abs(cosA) > 0.5) {
        curRx += bxs * (Math.abs(cosA) - 0.5) * 2;
      }

      let curRz = rz;
      if (bzf > 0 && sinA > 0) {
        // Forward pectoral / abdominal fullness
        curRz += bzf * Math.pow(sinA, 1.6);
      } else if (izb !== 0 && sinA < 0) {
        // Spine groove indentation
        curRz -= izb * Math.pow(-sinA, 2.0);
      }

      const x = cx + cosA * curRx;
      const z = cz + sinA * curRz;
      const y = s.y;

      positions.push(x, y, z);
      uvs.push(u, v);
    }
  }

  const stride = radialSegments + 1;
  for (let j = 0; j < slices.length - 1; j++) {
    for (let i = 0; i < radialSegments; i++) {
      const a = j * stride + i;
      const b = (j + 1) * stride + i;
      const c = (j + 1) * stride + (i + 1);
      const d = j * stride + (i + 1);
      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  // Optional caps
  if (closeBottom) {
    const centerIdx = positions.length / 3;
    const bottomSlice = slices[0];
    positions.push(bottomSlice.cx || 0, bottomSlice.y, bottomSlice.cz || 0);
    uvs.push(0.5, 0);
    for (let i = 0; i < radialSegments; i++) {
      indices.push(centerIdx, i + 1, i);
    }
  }

  if (closeTop) {
    const centerIdx = positions.length / 3;
    const topSlice = slices[slices.length - 1];
    const topRowStart = (slices.length - 1) * stride;
    positions.push(topSlice.cx || 0, topSlice.y, topSlice.cz || 0);
    uvs.push(0.5, 1);
    for (let i = 0; i < radialSegments; i++) {
      indices.push(centerIdx, topRowStart + i, topRowStart + i + 1);
    }
  }

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geom.setIndex(indices);
  geom.computeVertexNormals();
  return geom;
}

/**
 * Builds Azrael's complete athletic humanoid torso with muscular pectorals, lats, and spine
 */
export function createAthleticHumanoidTorso(): THREE.BufferGeometry {
  const slices: LoftedSlice[] = [
    { y: -0.22, rx: 0.19,  rz: 0.135, cz: 0.01, bulgeZFront: 0.01 }, // Lower pelvic base
    { y: -0.12, rx: 0.175, rz: 0.125, cz: 0.01, bulgeZFront: 0.02 }, // Narrow athletic waist
    { y: 0.0,   rx: 0.205, rz: 0.135, cz: 0.02, bulgeZFront: 0.035, indentZBack: 0.012 }, // Solar plexus & serratus
    { y: 0.14,  rx: 0.25,  rz: 0.165, cz: 0.03, bulgeZFront: 0.065, bulgeXSide: 0.035, indentZBack: 0.018 }, // Muscular lats
    { y: 0.26,  rx: 0.275, rz: 0.175, cz: 0.04, bulgeZFront: 0.075, bulgeXSide: 0.045, indentZBack: 0.022 }, // Broad muscular chest
    { y: 0.38,  rx: 0.265, rz: 0.155, cz: 0.03, bulgeZFront: 0.055, bulgeXSide: 0.035 }, // Clavicle shelf
    { y: 0.44,  rx: 0.16,  rz: 0.12,  cz: 0.02 }, // Trapezius & neck base
  ];
  return createLoftedBodyGeometry(slices, 24, true, true);
}

/**
 * Builds Azrael's fitted gothic Damascus steel cuirass with central tapul ridge and fauld lames
 */
export function createFittedCuirass(): THREE.BufferGeometry {
  const slices: LoftedSlice[] = [
    { y: -0.18, rx: 0.215, rz: 0.155, cz: 0.01, bulgeZFront: 0.025 }, // Fauld lame flange
    { y: -0.06, rx: 0.205, rz: 0.145, cz: 0.01, bulgeZFront: 0.035 }, // Lower breastplate
    { y: 0.08,  rx: 0.24,  rz: 0.168, cz: 0.03, bulgeZFront: 0.068, bulgeXSide: 0.025 }, // Mid breastplate
    { y: 0.22,  rx: 0.285, rz: 0.188, cz: 0.04, bulgeZFront: 0.095, bulgeXSide: 0.035 }, // Gothic tapul apex
    { y: 0.36,  rx: 0.272, rz: 0.168, cz: 0.03, bulgeZFront: 0.065 }, // Upper gorget rim
  ];
  return createLoftedBodyGeometry(slices, 24, false, false);
}

/**
 * Builds Azrael's sculpted face and head with jawline, chin, brow, nose, and scar
 */
export function createSculptedHead(): THREE.BufferGeometry {
  const slices: LoftedSlice[] = [
    { y: -0.16, rx: 0.055, rz: 0.075, cz: 0.025 }, // Chiseled masculine chin
    { y: -0.10, rx: 0.088, rz: 0.098, cz: 0.032, bulgeZFront: 0.028, bulgeXSide: 0.018 }, // Defined jawline angle
    { y: -0.04, rx: 0.105, rz: 0.115, cz: 0.035, bulgeZFront: 0.042 }, // Mouth & philtrum
    { y: 0.03,  rx: 0.112, rz: 0.122, cz: 0.038, bulgeZFront: 0.055, bulgeXSide: 0.028 }, // Cheekbones & nose bridge
    { y: 0.09,  rx: 0.114, rz: 0.124, cz: 0.028, bulgeZFront: 0.045 }, // Brow ridge & eye socket
    { y: 0.14,  rx: 0.11,  rz: 0.116, cz: 0.012 }, // Forehead
    { y: 0.19,  rx: 0.092, rz: 0.098, cz: 0.0 }, // Upper skull
    { y: 0.23,  rx: 0.06,  rz: 0.068, cz: -0.01 }, // Cranium crown
  ];
  return createLoftedBodyGeometry(slices, 24, true, true);
}

/**
 * Builds anatomical limb segment (bicep / forearm / thigh / calf)
 */
export function createAnatomicalLimb(
  upperR: number,
  midR: number,
  lowerR: number,
  length: number,
  bulgeFront: number = 0,
  bulgeSide: number = 0
): THREE.BufferGeometry {
  const slices: LoftedSlice[] = [
    { y: 0, rx: upperR, rz: upperR },
    { y: -length * 0.35, rx: midR + bulgeSide, rz: midR + bulgeFront, bulgeZFront: bulgeFront },
    { y: -length * 0.7, rx: (midR + lowerR) * 0.5, rz: (midR + lowerR) * 0.5 },
    { y: -length, rx: lowerR, rz: lowerR },
  ];
  return createLoftedBodyGeometry(slices, 16, true, true);
}

/**
 * Builds an articulated anatomical hand with palm and fingers
 */
export function createArticulatedHand(isRight: boolean, material: THREE.Material): THREE.Group {
  const handGroup = new THREE.Group();
  const sign = isRight ? 1 : -1;

  // 1. Palm / Metacarpal block
  const palmGeom = new THREE.BoxGeometry(0.08, 0.09, 0.045);
  const palm = new THREE.Mesh(palmGeom, material);
  palm.position.set(0, -0.045, 0);
  palm.castShadow = true;
  handGroup.add(palm);

  // 2. Articulated Thumb
  const thumbBase = new THREE.Group();
  thumbBase.position.set(sign * 0.045, -0.025, 0.015);
  thumbBase.rotation.set(0.3, sign * 0.6, -sign * 0.4);
  handGroup.add(thumbBase);

  const thumbProximal = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.012, 0.04, 6), material);
  thumbProximal.position.y = -0.02;
  thumbBase.add(thumbProximal);

  const thumbDistal = new THREE.Mesh(new THREE.ConeGeometry(0.012, 0.035, 6), material);
  thumbDistal.rotation.x = Math.PI;
  thumbDistal.position.y = -0.055;
  thumbBase.add(thumbDistal);

  // 3. Four Curled Fingers (Index, Middle, Ring, Pinky) holding weapon hilt
  const fingerConfigs = [
    { offset: 0.03, len: 0.075, thick: 0.012 }, // Index
    { offset: 0.01, len: 0.082, thick: 0.013 }, // Middle
    { offset: -0.01, len: 0.078, thick: 0.012 }, // Ring
    { offset: -0.03, len: 0.065, thick: 0.011 }, // Pinky
  ];

  fingerConfigs.forEach((cfg) => {
    const fingerGroup = new THREE.Group();
    fingerGroup.position.set(sign * cfg.offset, -0.09, 0);
    // Curl finger inward to grasp weapon handle
    fingerGroup.rotation.x = Math.PI * 0.55;
    handGroup.add(fingerGroup);

    const f1 = new THREE.Mesh(new THREE.CylinderGeometry(cfg.thick, cfg.thick * 0.9, cfg.len * 0.55, 6), material);
    f1.position.y = -cfg.len * 0.28;
    fingerGroup.add(f1);

    const f2 = new THREE.Mesh(new THREE.CylinderGeometry(cfg.thick * 0.9, cfg.thick * 0.7, cfg.len * 0.5, 6), material);
    f2.position.set(0, -cfg.len * 0.55, 0.015);
    f2.rotation.x = 0.5;
    fingerGroup.add(f2);
  });

  return handGroup;
}

/**
 * Builds sculpted gothic pointed sabaton foot with articulated lames and heel spur
 */
export function createGothicSabatonFoot(material: THREE.Material, silverMat: THREE.Material): THREE.Group {
  const foot = new THREE.Group();

  // 1. Ankle & Heel cup
  const heel = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.08, 0.12), material);
  heel.position.set(0, -0.04, -0.04);
  heel.castShadow = true;
  foot.add(heel);

  // 2. Arch & Metatarsal ridge
  const instep = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.14, 5), material);
  instep.rotation.x = Math.PI * 0.45;
  instep.position.set(0, -0.03, 0.04);
  foot.add(instep);

  // 3. Pointed gothic toe (Poulin / Cracowe point)
  const toePoint = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.14, 4), silverMat);
  toePoint.rotation.x = -Math.PI / 2;
  toePoint.position.set(0, -0.05, 0.15);
  toePoint.castShadow = true;
  foot.add(toePoint);

  // 4. Heel spur
  const spur = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.06, 4), silverMat);
  spur.rotation.x = Math.PI / 2;
  spur.position.set(0, -0.03, -0.11);
  foot.add(spur);

  return foot;
}

/**
 * Builds multi-tiered curved spiked gothic pauldron
 */
export function createTieredGothicPauldron(
  isRight: boolean,
  damascusMat: THREE.Material,
  silverMat: THREE.Material
): THREE.Group {
  const pauldron = new THREE.Group();
  const sign = isRight ? -1 : 1;

  // Main shoulder dome conforming over deltoid
  const domeGeom = new THREE.SphereGeometry(0.2, 12, 10, 0, Math.PI, 0, Math.PI * 0.65);
  const dome = new THREE.Mesh(domeGeom, damascusMat);
  dome.rotation.z = sign * 0.35;
  dome.rotation.x = -Math.PI / 2;
  dome.scale.set(1.1, 0.9, 1.2);
  dome.castShadow = true;
  pauldron.add(dome);

  // Flared gothic gardbrace (upper neck-guard fin)
  const finGeom = new THREE.ConeGeometry(0.12, 0.38, 4);
  const fin = new THREE.Mesh(finGeom, silverMat);
  fin.rotation.z = -sign * Math.PI * 0.32;
  fin.rotation.x = 0.1;
  fin.position.set(sign * 0.08, 0.15, -0.02);
  fin.castShadow = true;
  pauldron.add(fin);

  // Swept outer tier blades
  for (let i = 0; i < 3; i++) {
    const lameGeom = new THREE.CylinderGeometry(0.19 - i * 0.02, 0.21 - i * 0.02, 0.07, 8, 1, true, 0, Math.PI);
    const lame = new THREE.Mesh(lameGeom, i === 1 ? silverMat : damascusMat);
    lame.position.set(sign * (0.04 + i * 0.03), -0.06 - i * 0.06, 0);
    lame.rotation.z = sign * (0.4 + i * 0.15);
    lame.castShadow = true;
    pauldron.add(lame);
  }

  // Gothic crest spike
  const crestSpike = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.22, 4), silverMat);
  crestSpike.position.set(sign * 0.14, 0.24, 0);
  crestSpike.rotation.z = -sign * 0.5;
  crestSpike.castShadow = true;
  pauldron.add(crestSpike);

  return pauldron;
}

/**
 * Builds Azrael's iconic Executioner Greatsword with glowing cyan runic fuller
 */
export function createExecutionerGreatsword(
  bladeSteelMat: THREE.Material,
  runeGlowMat: THREE.Material,
  silverMat: THREE.Material,
  leatherMat: THREE.Material
): { swordGroup: THREE.Group; runeLight: THREE.PointLight } {
  const sword = new THREE.Group();

  // 1. Central Blade Geometry (Double-edged broad executioner blade)
  const bladeShape = new THREE.Shape();
  bladeShape.moveTo(0.11, 0);
  bladeShape.lineTo(0.10, 1.7);
  bladeShape.lineTo(0.12, 1.82); // Flared executioner bevel
  bladeShape.lineTo(0, 2.05);    // Chiseled diamond point
  bladeShape.lineTo(-0.12, 1.82);
  bladeShape.lineTo(-0.10, 1.7);
  bladeShape.lineTo(-0.11, 0);
  bladeShape.closePath();

  const extrudeSettings: THREE.ExtrudeGeometryOptions = {
    depth: 0.028,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 1,
    bevelSize: 0.012,
    bevelThickness: 0.014,
  };

  const bladeGeom = new THREE.ExtrudeGeometry(bladeShape, extrudeSettings);
  bladeGeom.center();
  const blade = new THREE.Mesh(bladeGeom, bladeSteelMat);
  blade.position.y = 1.05;
  blade.castShadow = true;
  sword.add(blade);

  // 2. Central Fuller with Glowing Supernatural Runes (Front & Back)
  const fullerGeom = new THREE.BoxGeometry(0.065, 1.55, 0.058);
  const fullerMesh = new THREE.Mesh(fullerGeom, runeGlowMat);
  fullerMesh.position.y = 1.0;
  sword.add(fullerMesh);

  // 3. Down-curved Gothic Crossguard with Quillons
  const guard = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.08, 0.11), silverMat);
  guard.position.y = 0.05;
  guard.castShadow = true;
  sword.add(guard);

  const quillonL = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.24, 4), silverMat);
  quillonL.rotation.z = Math.PI * 0.72;
  quillonL.position.set(0.35, -0.02, 0);
  sword.add(quillonL);

  const quillonR = new THREE.Mesh(new THREE.ConeGeometry(0.065, 0.24, 4), silverMat);
  quillonR.rotation.z = -Math.PI * 0.72;
  quillonR.position.set(-0.35, -0.02, 0);
  sword.add(quillonR);

  // Central Gothic Crest Jewel
  const jewel = new THREE.Mesh(new THREE.OctahedronGeometry(0.06), runeGlowMat);
  jewel.position.set(0, 0.05, 0.065);
  sword.add(jewel);

  // 4. Two-Handed Grip with Wire Wrap
  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.034, 0.52, 10), leatherMat);
  grip.position.y = -0.22;
  sword.add(grip);

  // Grip wire ribs
  for (let w = 0; w < 6; w++) {
    const wire = new THREE.Mesh(new THREE.TorusGeometry(0.039, 0.005, 6, 12), silverMat);
    wire.rotation.x = Math.PI / 2;
    wire.position.y = -0.06 - w * 0.07;
    sword.add(wire);
  }

  // 5. Faceted Diamond Pommel with Occult Engraving
  const pommel = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.16, 6), silverMat);
  pommel.rotation.x = Math.PI;
  pommel.position.y = -0.54;
  sword.add(pommel);

  // 6. Supernatural Cyan Light Source on the Blade
  const runeLight = new THREE.PointLight(0x38bdf8, 0.75, 3.2);
  runeLight.position.set(0, 1.1, 0.12);
  sword.add(runeLight);

  return { swordGroup: sword, runeLight };
}

/**
 * Builds anatomical demonic creature geometry (Hellspawn, Hellbrute, Shade, etc.)
 */
export function createDemonicBeastTorso(isHeavy: boolean = false): THREE.BufferGeometry {
  const slices: LoftedSlice[] = isHeavy
    ? [
        { y: -0.3, rx: 0.32, rz: 0.24, cz: 0.02 }, // Pelvic base
        { y: -0.1, rx: 0.36, rz: 0.28, cz: 0.04, bulgeZFront: 0.05 }, // Heavy belly
        { y: 0.15, rx: 0.44, rz: 0.34, cz: 0.08, bulgeZFront: 0.09, bulgeXSide: 0.06 }, // Muscular ribcage
        { y: 0.45, rx: 0.52, rz: 0.38, cz: 0.12, bulgeZFront: 0.12, bulgeXSide: 0.08, indentZBack: 0.03 }, // Immense brute chest
        { y: 0.68, rx: 0.46, rz: 0.32, cz: 0.16, bulgeZFront: 0.08 }, // Massive shoulders/traps
        { y: 0.82, rx: 0.28, rz: 0.22, cz: 0.20 }, // Hunched forward neck
      ]
    : [
        { y: -0.25, rx: 0.16, rz: 0.13, cz: 0.01 }, // Sinewy fiend pelvis
        { y: -0.1,  rx: 0.14, rz: 0.12, cz: 0.02, bulgeZFront: 0.02 }, // Starved demon waist
        { y: 0.1,   rx: 0.20, rz: 0.16, cz: 0.06, bulgeZFront: 0.05, indentZBack: 0.02 }, // Exposed sinewy ribs
        { y: 0.3,   rx: 0.23, rz: 0.18, cz: 0.10, bulgeZFront: 0.07, bulgeXSide: 0.03 }, // Predatory chest
        { y: 0.48,  rx: 0.18, rz: 0.14, cz: 0.14, bulgeZFront: 0.04 }, // Hunched neck base
      ];

  return createLoftedBodyGeometry(slices, 20, true, true);
}

/**
 * Builds digitigrade demon leg (thigh, backwards hock joint, cannon bone, and raptor talons)
 */
export function createDigitigradeDemonLeg(materials: { flesh: THREE.Material; bone: THREE.Material; claw: THREE.Material }): THREE.Group {
  const leg = new THREE.Group();

  // 1. Muscular upper thigh
  const thighGeom = createAnatomicalLimb(0.14, 0.12, 0.09, 0.42, 0.04);
  const thigh = new THREE.Mesh(thighGeom, materials.flesh);
  thigh.rotation.x = -0.35; // Forward lean
  thigh.castShadow = true;
  leg.add(thigh);

  // 2. Knee & Backwards Hock Joint
  const hockJoint = new THREE.Group();
  hockJoint.position.set(0, -0.38, 0.14);
  hockJoint.rotation.x = 0.85; // Sharp backwards bend (digitigrade)
  leg.add(hockJoint);

  const hockSpike = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.16, 4), materials.bone);
  hockSpike.rotation.x = -Math.PI / 2;
  hockSpike.position.set(0, 0, -0.08);
  hockJoint.add(hockSpike);

  // 3. Lower Cannon Bone / Shank
  const shankGeom = createAnatomicalLimb(0.09, 0.07, 0.05, 0.48, 0.02);
  const shank = new THREE.Mesh(shankGeom, materials.flesh);
  hockJoint.add(shank);

  // 4. Raptor Talon Foot
  const foot = new THREE.Group();
  foot.position.set(0, -0.48, 0);
  foot.rotation.x = -0.5;
  hockJoint.add(foot);

  // Three forward talons + one dewclaw
  for (let t = -1; t <= 1; t++) {
    const claw = new THREE.Mesh(new THREE.ConeGeometry(0.028, 0.16, 4), materials.claw);
    claw.rotation.x = -Math.PI * 0.45;
    claw.rotation.z = t * 0.25;
    claw.position.set(t * 0.04, -0.02, 0.08);
    claw.castShadow = true;
    foot.add(claw);
  }

  const dewclaw = new THREE.Mesh(new THREE.ConeGeometry(0.022, 0.11, 4), materials.claw);
  dewclaw.rotation.x = Math.PI * 0.45;
  dewclaw.position.set(0, -0.01, -0.06);
  foot.add(dewclaw);

  return leg;
}

/**
 * Builds elongated snarling demon skull with articulated fanged jaw and horns
 */
export function createDemonicSkull(materials: { bone: THREE.Material; eye: THREE.Material }): THREE.Group {
  const headGroup = new THREE.Group();

  // 1. Elongated Predatory Cranium
  const skullSlices: LoftedSlice[] = [
    { y: -0.08, rx: 0.08, rz: 0.18, cz: 0.08 }, // Snout tip
    { y: 0.0,   rx: 0.12, rz: 0.22, cz: 0.06, bulgeZFront: 0.04 }, // Nasal bridge & brow
    { y: 0.10,  rx: 0.14, rz: 0.18, cz: 0.02, bulgeXSide: 0.03 }, // Eye sockets & zygomatic arches
    { y: 0.18,  rx: 0.12, rz: 0.14, cz: -0.03 }, // Cranial vault
  ];
  const craniumGeom = createLoftedBodyGeometry(skullSlices, 16, true, true);
  const cranium = new THREE.Mesh(craniumGeom, materials.bone);
  cranium.castShadow = true;
  headGroup.add(cranium);

  // 2. Lower Snarling Jaw with Fangs
  const jaw = new THREE.Group();
  jaw.position.set(0, -0.06, 0.02);
  jaw.rotation.x = 0.28; // Open snarling maw
  headGroup.add(jaw);

  const jawMesh = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.22, 4), materials.bone);
  jawMesh.rotation.x = -Math.PI / 2;
  jawMesh.position.set(0, 0, 0.1);
  jaw.add(jawMesh);

  // Sharp fangs lining upper and lower jaws
  for (let f = -2; f <= 2; f++) {
    const fangUpper = new THREE.Mesh(new THREE.ConeGeometry(0.014, 0.06, 4), materials.bone);
    fangUpper.rotation.x = Math.PI;
    fangUpper.position.set(f * 0.028, -0.04, 0.18 - Math.abs(f) * 0.02);
    headGroup.add(fangUpper);

    const fangLower = new THREE.Mesh(new THREE.ConeGeometry(0.014, 0.06, 4), materials.bone);
    fangLower.position.set(f * 0.025, 0.03, 0.18 - Math.abs(f) * 0.02);
    jaw.add(fangLower);
  }

  // 3. Swept Obsidian Horns
  for (let s = -1; s <= 1; s += 2) {
    const hornGroup = new THREE.Group();
    hornGroup.position.set(s * 0.11, 0.12, -0.02);
    hornGroup.rotation.set(-0.3, s * 0.4, s * 0.5);
    headGroup.add(hornGroup);

    const hornGeom = new THREE.ConeGeometry(0.05, 0.42, 6);
    const horn = new THREE.Mesh(hornGeom, materials.bone);
    horn.position.y = 0.2;
    horn.castShadow = true;
    hornGroup.add(horn);
  }

  // 4. Glowing Predatory Eyes
  for (let s = -1; s <= 1; s += 2) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), materials.eye);
    eye.position.set(s * 0.085, 0.05, 0.12);
    headGroup.add(eye);
  }

  return headGroup;
}
