/**
 * The Seven Hellgates - Root Application Component
 */

import React, { useEffect, useRef, useState } from 'react';
import { HellgatesGame, GameUIState } from './game/HellgatesGame';
import { GameHUD } from './components/GameHUD';
import { MobileControls } from './components/MobileControls';
import { AltarModal } from './components/AltarModal';
import { RealmTravelModal } from './components/RealmTravelModal';
import { WhiteEyedGodCutscene } from './components/WhiteEyedGodCutscene';
import { MainMenu } from './components/MainMenu';
import { BlenderStudioModal } from './components/BlenderStudioModal';
import { resetPlayerData } from './game/storage';
import { PlayerStats } from './game/types';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<HellgatesGame | null>(null);

  const [uiState, setUiState] = useState<GameUIState | null>(null);
  const [isInMainMenu, setIsInMainMenu] = useState(true);
  const [isAltarOpen, setIsAltarOpen] = useState(false);
  const [isTravelOpen, setIsTravelOpen] = useState(false);
  const [isBlenderStudioOpen, setIsBlenderStudioOpen] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  useEffect(() => {
    // Detect touch device capability
    const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    setIsTouchDevice(hasTouch);

    if (!containerRef.current) return;

    // Initialize 3D Engine
    const game = new HellgatesGame(containerRef.current, (state) => {
      setUiState({ ...state });
    });
    gameRef.current = game;

    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  const handleStartGame = () => {
    setIsInMainMenu(false);
  };

  const handleResetGame = () => {
    const fresh = resetPlayerData();
    if (gameRef.current) {
      gameRef.current.playerData = fresh;
      gameRef.current.loadRealm(1);
    }
  };

  const handleUpgradeStat = (stat: keyof PlayerStats) => {
    if (gameRef.current) {
      gameRef.current.upgradeStat(stat);
    }
  };

  const handleSelectRealm = (realmId: number) => {
    if (gameRef.current) {
      gameRef.current.loadRealm(realmId);
    }
  };

  const handleRestart = () => {
    if (gameRef.current) {
      gameRef.current.restartRealm();
    }
  };

  const handleAdvanceRealm = () => {
    if (gameRef.current) {
      gameRef.current.advanceToNextRealm();
    }
  };

  const handleSwitchStance = () => {
    if (gameRef.current) {
      gameRef.current.switchStance();
    }
  };

  const handleActivateWrath = () => {
    if (gameRef.current) {
      gameRef.current.activateWrath();
    }
  };

  const handleMobileAction = (action: 'light' | 'heavy' | 'dodge' | 'stance' | 'ability' | 'wrath' | 'lock') => {
    if (gameRef.current) {
      gameRef.current.triggerMobileAction(action);
    }
  };

  const handleMobileMove = (x: number, z: number) => {
    if (gameRef.current) {
      gameRef.current.setVirtualMove(x, z);
    }
  };

  const handleMobileLook = (dx: number, dy: number) => {
    if (gameRef.current) {
      gameRef.current.setVirtualLook(dx, dy);
    }
  };

  const handleCycleGraphics = () => {
    if (gameRef.current) {
      gameRef.current.cycleGraphicsPreset();
    }
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black text-slate-100 select-none">
      {/* 1. Dedicated Three.js WebGL Mount Ref */}
      <div
        ref={containerRef}
        className="absolute inset-0 w-full h-full cursor-crosshair"
      />

      {/* 2. Main Menu Overlay */}
      {isInMainMenu && gameRef.current && (
        <MainMenu
          playerData={gameRef.current.playerData}
          onStartGame={handleStartGame}
          onResetGame={handleResetGame}
          onOpenBlenderStudio={() => setIsBlenderStudioOpen(true)}
        />
      )}

      {/* 3. In-Game HUD (when active) */}
      {!isInMainMenu && uiState && (
        <>
          <GameHUD
            uiState={uiState}
            onOpenAltar={() => setIsAltarOpen(true)}
            onOpenTravel={() => setIsTravelOpen(true)}
            onOpenBlenderStudio={() => setIsBlenderStudioOpen(true)}
            onRestart={handleRestart}
            onAdvanceRealm={handleAdvanceRealm}
            onSwitchStance={handleSwitchStance}
            onActivateWrath={handleActivateWrath}
            onCycleGraphics={handleCycleGraphics}
          />

          {/* 4. Mobile On-Screen Controls */}
          {isTouchDevice && (
            <MobileControls
              onMove={handleMobileMove}
              onLookDelta={handleMobileLook}
              onAction={handleMobileAction}
              currentStance={uiState.stance}
              wrathReady={uiState.wrath >= 50}
            />
          )}

          {/* 5. Altar of Ash Modal */}
          {isAltarOpen && gameRef.current && (
            <AltarModal
              playerData={gameRef.current.playerData}
              onUpgrade={handleUpgradeStat}
              onClose={() => setIsAltarOpen(false)}
            />
          )}

          {/* 6. Realm Portal Travel Modal */}
          {isTravelOpen && gameRef.current && (
            <RealmTravelModal
              currentRealmId={gameRef.current.playerData.currentRealm}
              unlockedRealms={uiState.unlockedRealms}
              defeatedBosses={gameRef.current.playerData.defeatedBosses}
              onSelectRealm={handleSelectRealm}
              onClose={() => setIsTravelOpen(false)}
            />
          )}

          {/* 7. The White-Eyed God Climactic Sequence */}
          {uiState.isWhiteEyedGodActive && (
            <WhiteEyedGodCutscene
              onRestart={() => {
                handleResetGame();
                setIsInMainMenu(true);
              }}
            />
          )}
        </>
      )}

      {/* 8. Blender 3D Studio & Model Inspector Modal */}
      <BlenderStudioModal
        isOpen={isBlenderStudioOpen}
        onClose={() => setIsBlenderStudioOpen(false)}
      />
    </div>
  );
}
