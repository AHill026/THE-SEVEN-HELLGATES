/**
 * The Seven Hellgates - The White-Eyed God Climactic Reveal
 * Strict adherence: No body, no face, no silhouette.
 * Only two enormous glowing white eyes in total cosmic darkness whispering "Azrael...".
 * Cut to black and title reveal: "FACE YOUR FINAL JUDGMENT."
 */

import React, { useEffect, useState } from 'react';
import { audioManager } from '../audio/audio-manager';

interface WhiteEyedGodCutsceneProps {
  onRestart: () => void;
}

export const WhiteEyedGodCutscene: React.FC<WhiteEyedGodCutsceneProps> = ({ onRestart }) => {
  const [stage, setStage] = useState<'stare' | 'whisper' | 'cutToBlack' | 'titleReveal'>('stare');

  useEffect(() => {
    // Trigger cinematic White-Eyed God audio sequence
    audioManager.playWhiteEyedGodRevelation();

    // Stage timing aligned with audio
    const t1 = setTimeout(() => setStage('whisper'), 2500);
    const t2 = setTimeout(() => setStage('cutToBlack'), 5500);
    const t3 = setTimeout(() => setStage('titleReveal'), 7500);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center select-none overflow-hidden text-center">
      {/* 1. Stare & Whisper Stage */}
      {(stage === 'stare' || stage === 'whisper') && (
        <div className="relative flex flex-col items-center justify-center w-full h-full">
          {/* Subtle cosmic vignette */}
          <div className="absolute inset-0 bg-radial from-transparent via-black/80 to-black pointer-events-none" />

          {/* Two enormous glowing white eyes suspended in complete darkness (no face, no body) */}
          <div className="flex items-center gap-24 md:gap-36 relative z-10">
            {/* Left Eye */}
            <div className="relative w-24 h-12 md:w-36 md:h-16 rounded-[50%] bg-white shadow-[0_0_80px_35px_rgba(255,255,255,0.85)]" />
            {/* Right Eye */}
            <div className="relative w-24 h-12 md:w-36 md:h-16 rounded-[50%] bg-white shadow-[0_0_80px_35px_rgba(255,255,255,0.85)]" />
          </div>

          {/* Whispered Text */}
          {stage === 'whisper' && (
            <div className="absolute bottom-28 z-20 transition-opacity duration-1000 opacity-90">
              <p className="text-xl md:text-2xl font-gothic italic tracking-[0.3em] text-white/90 drop-shadow-[0_0_15px_rgba(255,255,255,0.6)]">
                “Azrael…”
              </p>
            </div>
          )}
        </div>
      )}

      {/* 2. Absolute Blackout */}
      {stage === 'cutToBlack' && (
        <div className="fixed inset-0 bg-black transition-opacity duration-700" />
      )}

      {/* 3. Title Card & Sequel Teaser */}
      {stage === 'titleReveal' && (
        <div className="relative z-20 flex flex-col items-center justify-center p-6 max-w-xl mx-auto animate-fadeIn">
          <h1 className="text-3xl md:text-5xl font-black font-gothic tracking-[0.25em] text-white drop-shadow-[0_0_25px_rgba(255,255,255,0.4)] mb-3">
            THE SEVEN HELLGATES
          </h1>

          <div className="w-32 h-[1px] bg-gradient-to-r from-transparent via-blue-400 to-transparent my-6" />

          <p className="text-lg md:text-xl font-bold font-gothic tracking-[0.2em] text-red-500 drop-shadow-[0_0_12px_rgba(239,68,68,0.7)] mb-4">
            FACE YOUR FINAL JUDGMENT.
          </p>

          <p className="text-xs md:text-sm text-slate-400 font-sans tracking-wide leading-relaxed max-w-md mb-8">
            The seven demonic rulers have fallen. Yet beyond the threshold of creation, the White-Eyed God has awakened.
            Azrael's forgotten origin and true purpose await in the sequel.
          </p>

          <button
            onClick={onRestart}
            className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white border border-slate-700 hover:border-slate-500 rounded-xl font-gothic tracking-widest text-xs uppercase transition-all shadow-xl hover:shadow-blue-900/30 active:scale-95"
          >
            Awaken Once More (New Game +)
          </button>
        </div>
      )}
    </div>
  );
};
