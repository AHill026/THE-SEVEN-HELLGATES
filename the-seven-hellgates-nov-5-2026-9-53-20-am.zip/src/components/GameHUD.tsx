/**
 * The Seven Hellgates - In-Game HUD & Interface
 * Responsive, dark-fantasy aesthetic, zero viewport occlusion.
 */

import React from 'react';
import { GameUIState } from '../game/HellgatesGame';
import { Flame, Shield, Volume2, VolumeX, RotateCcw, Compass, MapPin, Zap, Skull, Sparkles, Box, Sliders } from 'lucide-react';
import { audioManager } from '../audio/audio-manager';
import { AudioSettingsModal } from './AudioSettingsModal';

interface GameHUDProps {
  uiState: GameUIState;
  onOpenAltar: () => void;
  onOpenTravel: () => void;
  onOpenBlenderStudio: () => void;
  onRestart: () => void;
  onAdvanceRealm: () => void;
  onSwitchStance: () => void;
  onActivateWrath: () => void;
  onCycleGraphics: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  uiState,
  onOpenAltar,
  onOpenTravel,
  onOpenBlenderStudio,
  onRestart,
  onAdvanceRealm,
  onSwitchStance,
  onActivateWrath,
  onCycleGraphics,
}) => {
  const [isAudioSettingsOpen, setIsAudioSettingsOpen] = React.useState(false);
  const isMuted = audioManager.settings.isMuted;

  const hpPercent = Math.max(0, Math.min(100, (uiState.health / uiState.maxHealth) * 100));
  const stamPercent = Math.max(0, Math.min(100, (uiState.stamina / uiState.maxStamina) * 100));
  const wrathPercent = Math.max(0, Math.min(100, (uiState.wrath / uiState.maxWrath) * 100));

  const stanceLabels: Record<string, { name: string; weapon: string; color: string }> = {
    reaper: { name: 'REAPER', weapon: 'Executioner Greatsword', color: 'text-blue-400 border-blue-500/40 bg-blue-950/40' },
    executioner: { name: 'EXECUTIONER', weapon: 'Hellforged Gauntlets', color: 'text-amber-400 border-amber-500/40 bg-amber-950/40' },
    wrath_unbound: { name: 'WRATH UNBOUND', weapon: 'Supernatural Awakening', color: 'text-cyan-300 border-cyan-400 bg-cyan-950/60 shadow-lg shadow-cyan-500/30' },
  };

  const currentStanceInfo = stanceLabels[uiState.stance] || stanceLabels.reaper;

  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-4 md:p-6 select-none">
      {/* --- TOP ROW --- */}
      <div className="flex items-start justify-between w-full">
        {/* Top-Left: Azrael Status Bars */}
        <div className="flex flex-col gap-2 pointer-events-auto">
          {/* Header Name & Embers */}
          <div className="flex items-center gap-3">
            <span className="font-gothic font-bold text-base md:text-lg tracking-wider text-slate-100 drop-shadow">
              AZRAEL
            </span>
            <div className="flex items-center gap-1 text-xs text-amber-400 font-bold bg-black/60 px-2.5 py-0.5 rounded-full border border-amber-500/30">
              <Flame className="w-3.5 h-3.5 fill-amber-400" />
              <span>{uiState.embers.toLocaleString()}</span>
            </div>
          </div>

          {/* Health Bar (Red) */}
          <div className="flex items-center gap-2">
            <div className="w-48 md:w-64 h-3.5 bg-black/70 rounded border border-red-950 p-0.5 relative overflow-hidden shadow-md">
              <div
                className="h-full bg-gradient-to-r from-red-700 via-red-600 to-red-500 rounded-sm transition-all duration-150"
                style={{ width: `${hpPercent}%` }}
              />
            </div>
            <span className="text-[11px] font-mono text-slate-300 font-semibold tabular-nums">
              {Math.round(uiState.health)}/{Math.round(uiState.maxHealth)}
            </span>
          </div>

          {/* Stamina Bar (Emerald/Amber) */}
          <div className="flex items-center gap-2">
            <div className="w-40 md:w-52 h-2.5 bg-black/70 rounded border border-emerald-950 p-0.5 relative overflow-hidden shadow-md">
              <div
                className="h-full bg-gradient-to-r from-emerald-600 to-teal-400 rounded-sm transition-all duration-75"
                style={{ width: `${stamPercent}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-slate-400 tabular-nums">
              {Math.round(uiState.stamina)}
            </span>
          </div>

          {/* Wrath Meter (Supernatural Cyan) */}
          <div className="flex items-center gap-2">
            <div className="w-36 md:w-44 h-2 bg-black/70 rounded border border-cyan-950 p-0.5 relative overflow-hidden">
              <div
                className={`h-full bg-gradient-to-r from-blue-600 to-cyan-400 rounded-sm transition-all duration-150 ${
                  wrathPercent >= 50 ? 'animate-pulse' : ''
                }`}
                style={{ width: `${wrathPercent}%` }}
              />
            </div>
            <span className="text-[10px] font-mono text-cyan-400 font-semibold">
              WRATH {Math.round(wrathPercent)}%
            </span>
          </div>

          {/* Stance Selector Pill Button */}
          <div className="mt-1 flex items-center gap-2">
            <button
              onClick={onSwitchStance}
              className={`flex items-center gap-2 px-3 py-1 rounded-lg border text-xs font-gothic tracking-wider font-bold transition-all pointer-events-auto active:scale-95 ${currentStanceInfo.color}`}
              title="Click or press Q to switch stance"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{currentStanceInfo.name}</span>
            </button>
            <span className="text-[10px] text-slate-400 hidden md:inline font-mono">
              [Q] Switch: {currentStanceInfo.weapon}
            </span>
          </div>
        </div>

        {/* Top-Right: Realm Banner & Quick Utility Controls */}
        <div className="flex flex-col items-end gap-2 pointer-events-auto">
          {/* Realm Indicator */}
          <div className="text-right">
            <div className="flex items-center gap-1.5 justify-end text-xs text-blue-400 font-gothic font-semibold tracking-wider">
              <MapPin className="w-3.5 h-3.5" />
              <span>REALM {uiState.currentRealm.id}: {uiState.currentRealm.name.toUpperCase()}</span>
            </div>
            <span className="text-[11px] text-slate-400 font-sans block">
              {uiState.currentRealm.subtitle}
            </span>
          </div>

          {/* Navigation & Altar Buttons */}
          <div className="flex items-center gap-2 mt-1">
            <button
              onClick={onOpenAltar}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 rounded-lg text-xs font-semibold text-slate-200 shadow-lg active:scale-95 transition-all"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Altar of Ash</span>
            </button>

            <button
              onClick={onOpenTravel}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 rounded-lg text-xs font-semibold text-slate-200 shadow-lg active:scale-95 transition-all"
            >
              <Compass className="w-3.5 h-3.5 text-blue-400" />
              <span>Hellgates</span>
            </button>

            <button
              onClick={onOpenBlenderStudio}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900/80 hover:bg-zinc-800 border border-amber-500/40 hover:border-amber-400 rounded-lg text-xs font-semibold text-amber-300 shadow-lg active:scale-95 transition-all"
              title="Open Blender 3D Studio & glTF Model Inspector"
            >
              <Box className="w-3.5 h-3.5 text-amber-400" />
              <span>Blender 3D</span>
            </button>

            <button
              onClick={onCycleGraphics}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 rounded-lg text-xs font-semibold text-slate-200 shadow-lg active:scale-95 transition-all"
              title="Toggle Graphics Preset (Ultra UE5 / Balanced / Low)"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-mono text-[11px] uppercase tracking-wider">
                {uiState.graphicsPreset === 'ultra' ? 'UE5 Ultra' : uiState.graphicsPreset === 'balanced' ? 'Balanced' : 'Low'}
              </span>
            </button>

            <button
              onClick={() => setIsAudioSettingsOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 rounded-lg text-xs font-semibold text-slate-200 shadow-lg active:scale-95 transition-all"
              title="Audio, Music & Sound Settings"
              aria-label="Audio Settings"
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-blue-400" />}
              <span className="text-[11px] font-mono hidden sm:inline">Audio</span>
            </button>

            <button
              onClick={onRestart}
              className="p-1.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 rounded-lg text-slate-400 hover:text-white transition-colors"
              aria-label="Restart Realm"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* --- TOP-CENTER OBJECTIVE BANNER --- */}
      {uiState.currentObjective && (
        <div className="self-center -mt-1 md:mt-0 px-4 py-1.5 rounded-full bg-black/65 backdrop-blur-md border border-slate-700/60 shadow-xl flex items-center gap-2 pointer-events-none transition-all">
          <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-sm shadow-cyan-400" />
          <span className="text-[11px] md:text-xs font-gothic tracking-wider text-slate-200">
            {uiState.currentObjective}
          </span>
        </div>
      )}

      {/* --- TOP-CENTER: BOSS HEALTH BAR (When Boss is active) --- */}
      {uiState.bossHealth !== null && uiState.bossMaxHealth !== null && uiState.bossHealth > 0 && (
        <div className="self-center w-full max-w-xl mx-auto flex flex-col items-center pointer-events-none mt-2 animate-fadeIn">
          <div className="flex items-center justify-between w-full px-2 mb-1">
            <div className="flex items-center gap-2">
              <Skull className="w-4 h-4 text-red-500" />
              <span className="font-gothic font-bold text-sm md:text-base tracking-widest text-slate-100 drop-shadow">
                {uiState.bossName}
              </span>
            </div>
            {uiState.bossPhase === 2 && (
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-red-400 bg-red-950/70 border border-red-500/40 px-2 py-0.5 rounded">
                ENRAGED (PHASE II)
              </span>
            )}
          </div>

          <div className="w-full h-3 bg-black/85 border border-red-900/80 rounded p-0.5 shadow-2xl overflow-hidden relative">
            <div
              className={`h-full rounded-sm transition-all duration-100 ${
                uiState.bossPhase === 2
                  ? 'bg-gradient-to-r from-red-600 via-orange-500 to-amber-400 animate-pulse'
                  : 'bg-gradient-to-r from-red-800 via-red-600 to-red-500'
              }`}
              style={{ width: `${Math.max(0, Math.min(100, (uiState.bossHealth / uiState.bossMaxHealth) * 100))}%` }}
            />
          </div>
        </div>
      )}

      {/* --- NON-BLOCKING MEMORY FRAGMENT LOG RIBBON (Never pauses gameplay) --- */}
      {uiState.currentMemoryLog && (
        <div className="self-center w-full max-w-xl mx-auto pointer-events-none mb-3 animate-fadeIn transition-all">
          <div className="bg-gradient-to-r from-cyan-950/90 via-black/90 to-blue-950/90 border border-cyan-500/50 rounded-2xl p-4 md:p-5 shadow-2xl backdrop-blur-md relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
            <div className="flex items-center gap-2.5 mb-2">
              <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span className="text-[11px] font-gothic font-bold uppercase tracking-[0.25em] text-cyan-300 drop-shadow">
                Memory Fragment Recovered
              </span>
              <span className="text-[10px] font-mono text-cyan-400/80 ml-auto">
                {uiState.currentMemoryLog.title}
              </span>
            </div>
            <p className="text-xs md:text-sm text-slate-200 italic font-serif leading-relaxed drop-shadow-sm">
              "{uiState.currentMemoryLog.text}"
            </p>
          </div>
        </div>
      )}

      {/* --- RECOVERED MEMORY FRAGMENT / LORE POPUP (Realm Complete) --- */}
      {uiState.loreFragment && uiState.isVictory && (
        <div className="self-center w-full max-w-lg bg-black/90 border border-blue-500/50 rounded-2xl p-6 text-center shadow-2xl pointer-events-auto animate-fadeIn backdrop-blur-md">
          <span className="text-xs uppercase font-gothic tracking-[0.2em] text-blue-400 block mb-1">
            Memory Fragment Restored
          </span>
          <h3 className="text-xl font-bold font-gothic text-slate-100 mb-3">
            {uiState.loreFragment.title}
          </h3>
          <p className="text-xs md:text-sm text-slate-300 italic leading-relaxed mb-5">
            “{uiState.loreFragment.text}”
          </p>

          <button
            onClick={onAdvanceRealm}
            className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-gothic text-xs tracking-widest uppercase transition-all shadow-lg shadow-blue-600/40 active:scale-95"
          >
            Enter Next Hellgate
          </button>
        </div>
      )}

      {/* --- GAME OVER BANNER --- */}
      {uiState.isGameOver && (
        <div className="self-center w-full max-w-md bg-black/90 border border-red-950 rounded-2xl p-6 text-center shadow-2xl pointer-events-auto animate-fadeIn">
          <h2 className="text-3xl font-black font-gothic tracking-[0.2em] text-red-500 drop-shadow mb-2">
            YOU DIED
          </h2>
          <p className="text-xs text-slate-400 mb-5">Your essence dissolved into the ash of the realm.</p>
          <button
            onClick={onRestart}
            className="px-6 py-2.5 bg-red-900/80 hover:bg-red-800 text-white border border-red-700/60 rounded-xl font-gothic text-xs tracking-widest uppercase transition-all shadow-lg active:scale-95"
          >
            Awaken at Gate
          </button>
        </div>
      )}

      {/* --- BOTTOM DESKTOP CONTROLS GUIDE (Collapsible hint) --- */}
      <div className="hidden md:flex items-center justify-center gap-6 text-[11px] font-mono text-slate-400 bg-black/60 backdrop-blur-sm border border-slate-800/80 px-4 py-1.5 rounded-full self-center">
        <span><strong className="text-slate-200">WASD</strong> Move</span>
        <span><strong className="text-slate-200">Space</strong> Dodge</span>
        <span><strong className="text-slate-200">LMB</strong> Light Combo</span>
        <span><strong className="text-slate-200">RMB</strong> Heavy Slam</span>
        <span><strong className="text-slate-200">Q</strong> Stance</span>
        <span><strong className="text-slate-200">E</strong> Quake</span>
        <span><strong className="text-slate-200">R</strong> Wrath</span>
        <span><strong className="text-slate-200">Tab</strong> Lock-on</span>
      </div>
      
      {/* --- AUDIO SETTINGS MODAL --- */}
      <AudioSettingsModal
        isOpen={isAudioSettingsOpen}
        onClose={() => setIsAudioSettingsOpen(false)}
      />
    </div>
  );
};
