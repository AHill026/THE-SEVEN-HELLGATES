# Implementation Plan - Unreal Engine 5 Cinematic Renderer & Blender Studio Integration

Integrate a high-fidelity Unreal Engine 5 post-processing pipeline and a Blender 3D Model Inspector with one-click glTF/GLB asset export directly into *The Seven Hellgates*.

---

## 1. Unreal Engine 5 Cinematic Post-Processing Pipeline
- **EffectComposer & Multi-Pass Stack**:
  - Integrate Three.js `EffectComposer`, `RenderPass`, and `UnrealBloomPass` (`threshold: 0.85, strength: 1.4, radius: 0.75`) to make Azrael's runic Greatsword, glowing blue eyes, memory crystals, wrath aura, and boss flames radiate supernatural light.
  - Implement a volumetric godray / sun-shaft shader pass emanating from the northern Hellgate portal.
  - Add screen-space contact ambient occlusion / vignetting for cinematic depth.
- **Dynamic Graphics Preset Control**:
  - **UE5 Ultra**: Full multi-pass composer with UnrealBloom, volumetric godrays, 2048px soft shadows, and tone-mapping exposure.
  - **Balanced**: Fast single-pass post-processing with optimized bloom and 1024px shadows.
  - **Low**: Raw high-FPS forward rendering pass for low-spec devices.

---

## 2. Blender Studio: In-Game 3D Model Inspector & glTF Exporter
- **Interactive Viewport Shading Modes**:
  - Replicate Blender's 4 viewport display modes:
    1. **Rendered (UE5 / PBR)**: Full lighting, normal maps, roughness, and emissions.
    2. **Material Preview (Clay / Studio MatCap)**: Neutral studio lighting for silhouette inspection.
    3. **Wireframe**: Visualizes topological edge loops and polygon tessellation.
    4. **Solid (Flat)**: Pure geometry shading.
- **Model Switcher**:
  - Inspect Azrael (Damascus armor, greatsword, cowl), The Hollow King, Hellspawn demon, Hellbrute, Shade, or Memory Fragment.
- **Blender Viewport Statistics Overlay**:
  - Real-time display of Vertex count, Triangle count, Submesh count, and Material slots.
- **One-Click Blender (.GLB / .GLTF) Asset Exporter**:
  - Uses `three/examples/jsm/exporters/GLTFExporter.js` to bundle binary `.glb` files with embedded PBR materials, hierarchical groups, and vertex normals ready for import into Blender 3D (`File > Import > glTF 2.0`).

---

## 3. UI Integration & Controls
- Add a **"Blender Studio"** button with a 3D cube icon in the top utility HUD and Main Menu.
- Include quick toggle shortcuts to switch between Live Gameplay and Model Inspection without losing game state.

---

## Verification Plan
1. **Compilation & Linting**: Run `compile_applet` and `lint_applet` to verify TypeScript typing and imports.
2. **UE5 Post-Processing Check**: Verify bloom emissive intensity on Azrael's greatsword and the Hellgate portal in Ultra mode.
3. **GLTF Export Test**: Open Blender Studio, select Azrael, trigger export, and verify binary `.glb` generation without errors.
