/**
 * The Seven Hellgates - Main 3D Game Engine Orchestrator
 */

import * as THREE from 'three';
import { PlayerData, CombatStance, RealmDefinition, EnemyType } from './types';
import { loadPlayerData, savePlayerData } from './storage';
import { AzraelModel } from './entities/AzraelModel';
import { EnemyInstance } from './entities/EnemyModels';
import { BossInstance, WhiteEyedGodEncounter } from './entities/BossModels';
import { RealmWorld, REALM_DEFINITIONS } from './worlds/RealmBuilder';
import { ParticleSystem } from './vfx/ParticleSystem';
import { CameraController } from './core/CameraController';
import { InputManager } from './core/InputManager';
import { CombatSystem } from './combat/CombatSystem';
import { soundEngine } from './audio/SoundEngine';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { MemoryFragment } from './entities/MemoryFragment';
import { HealthPickup } from './entities/HealthPickup';
import { FloorSpikeTrap, BurningBrazierHazard } from './entities/EnvironmentalHazards';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';

export type GraphicsPreset = 'ultra' | 'balanced' | 'low';

export interface RealmBattleStats {
  enemiesDefeated: number;
  peakCombo: number;
  embersEarned: number;
  elapsedSeconds: number;
  bossName: string;
}

export interface GameUIState {
  health: number;
  maxHealth: number;
  stamina: number;
  maxStamina: number;
  wrath: number;
  maxWrath: number;
  stance: CombatStance;
  level: number;
  embers: number;
  currentRealm: RealmDefinition;
  bossHealth: number | null;
  bossMaxHealth: number | null;
  bossName: string | null;
  bossPhase: number;
  isGameOver: boolean;
  isVictory: boolean;
  unlockedRealms: number[];
  loreFragment: { title: string; text: string } | null;
  isWhiteEyedGodActive: boolean;
  whiteEyedGodProgress: number; // 0 to 1
  graphicsPreset: GraphicsPreset;
  currentMemoryLog: { title: string; text: string } | null;
  currentObjective: string;
  isHealing: boolean;
  isPassivelyRegenerating: boolean;
  comboCount: number;
  comboTimerPercent: number;
  comboMultiplier: number;
  battleStats: RealmBattleStats;
}

export class HellgatesGame {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private cameraCtrl: CameraController;
  private inputMgr: InputManager;
  private clock: THREE.Clock;

  // Game Systems
  public azrael: AzraelModel;
  public realmWorld: RealmWorld;
  public particles: ParticleSystem;
  public combat: CombatSystem;
  public whiteEyedGod: WhiteEyedGodEncounter;

  // Entities & Pickups
  public enemies: EnemyInstance[] = [];
  public currentBoss: BossInstance | null = null;
  public healthPickups: HealthPickup[] = [];
  public spikeTraps: FloorSpikeTrap[] = [];
  public burningBraziers: BurningBrazierHazard[] = [];
  public playerData: PlayerData;
  public graphicsPreset: GraphicsPreset = 'ultra';

  // Realm Battle Statistics
  public realmEnemiesDefeated: number = 0;
  public realmPeakCombo: number = 0;
  public realmEmbersEarned: number = 0;
  public realmElapsedSeconds: number = 0;

  // Storyline & Memory Fragments
  public memoryFragments: MemoryFragment[] = [];
  public storylinePhase: 'exploration' | 'breach' | 'boss' = 'exploration';
  public currentMemoryLog: { title: string; text: string } | null = null;
  public memoryLogTimer: number = 0;
  public currentObjective: string = 'Prologue: Explore the silent ruins of Limbo';
  public collectedFragmentsCount: number = 0;

  // Lighting & Rendering
  private dirLight!: THREE.DirectionalLight;
  private rimLight!: THREE.DirectionalLight;
  private pmremGenerator!: THREE.PMREMGenerator;

  // UE5 Postprocessing Stack
  private composer!: EffectComposer;
  private renderPass!: RenderPass;
  private bloomPass!: UnrealBloomPass;
  private outputPass!: OutputPass;

  // Runtime flags
  private isRunning: boolean = false;
  private animFrameId: number = 0;
  private onUIUpdate: (state: GameUIState) => void;
  public isGameOver: boolean = false;
  public isVictory: boolean = false;
  public activeLore: { title: string; text: string } | null = null;
  public isWhiteEyedGodActive: boolean = false;
  private whiteEyedGodTimer: number = 0;

  constructor(container: HTMLElement, onUIUpdate: (state: GameUIState) => void) {
    this.container = container;
    this.onUIUpdate = onUIUpdate;
    this.clock = new THREE.Clock();

    // 1. Check Software WebGL guard
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Initialize Three.js Renderer (UE5 Tone Mapping & Color Pipeline)
    this.renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.25;
    this.renderer.shadowMap.enabled = !isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // 3. Scene & Physical Environment Reflection (RoomEnvironment)
    this.scene = new THREE.Scene();

    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.pmremGenerator.compileEquirectangularShader();
    const envTexture = this.pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = envTexture;

    // 4. UE5 Three-Point Cinematic Lighting Rig
    this.dirLight = new THREE.DirectionalLight(0xfff4e6, 2.0);
    this.dirLight.position.set(16, 28, 16);
    this.dirLight.castShadow = !isSoftwareGl;
    this.dirLight.shadow.mapSize.width = 2048;
    this.dirLight.shadow.mapSize.height = 2048;
    this.dirLight.shadow.camera.near = 1;
    this.dirLight.shadow.camera.far = 70;
    this.dirLight.shadow.camera.left = -30;
    this.dirLight.shadow.camera.right = 30;
    this.dirLight.shadow.camera.top = 30;
    this.dirLight.shadow.camera.bottom = -30;
    this.dirLight.shadow.bias = -0.0004;
    this.dirLight.shadow.normalBias = 0.02;
    this.scene.add(this.dirLight);

    // Cool blue-white specular rim light to carve out armor silhouettes
    this.rimLight = new THREE.DirectionalLight(0x7dd3fc, 1.2);
    this.rimLight.position.set(-20, 18, -20);
    this.scene.add(this.rimLight);

    const hemiLight = new THREE.HemisphereLight(0x334155, 0x0f172a, 1.0);
    this.scene.add(hemiLight);

    // 4. Subsystems
    this.cameraCtrl = new CameraController(60, container.clientWidth / container.clientHeight);
    this.inputMgr = new InputManager(this.renderer.domElement);
    this.particles = new ParticleSystem();
    this.scene.add(this.particles.group);

    this.realmWorld = new RealmWorld();
    this.scene.add(this.realmWorld.group);

    this.whiteEyedGod = new WhiteEyedGodEncounter();
    this.scene.add(this.whiteEyedGod.group);

    // 4.5. UE5 Cinematic Postprocessing (Unreal Bloom & Atmospheric Glow)
    this.composer = new EffectComposer(this.renderer);
    this.renderPass = new RenderPass(this.scene, this.cameraCtrl.camera);
    this.composer.addPass(this.renderPass);

    const bloomStrength = 1.35;
    const bloomRadius = 0.72;
    const bloomThreshold = 0.7;
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(container.clientWidth, container.clientHeight),
      bloomStrength,
      bloomRadius,
      bloomThreshold
    );
    this.composer.addPass(this.bloomPass);

    this.outputPass = new OutputPass();
    this.composer.addPass(this.outputPass);

    // 5. Load Player Data & Build Azrael
    this.playerData = loadPlayerData();
    this.combat = new CombatSystem(this.playerData.stats);

    this.azrael = new AzraelModel();
    this.azrael.group.position.set(0, 0, 5);
    this.scene.add(this.azrael.group);

    // Dynamic Realm Surface Footstep Acoustics:
    // Ash: Limbo (1), Heresy (5)
    // Blood: Gluttony (2), Violence (6)
    // Metallic: Greed (3), Wrath (4), Sovereign (7)
    this.azrael.onFootstep = (isSprinting: boolean) => {
      const realmId = this.playerData.currentRealm;
      let surface: 'ash' | 'blood' | 'metallic' = 'ash';
      if (realmId === 1 || realmId === 5) {
        surface = 'ash';
      } else if (realmId === 2 || realmId === 6) {
        surface = 'blood';
      } else {
        surface = 'metallic';
      }
      soundEngine.playFootstep(surface, isSprinting);
    };

    // 6. Build Initial Realm
    this.loadRealm(this.playerData.currentRealm);

    // Window resize handler
    window.addEventListener('resize', this.handleResize);

    this.start();
  }

  private handleResize = () => {
    if (!this.container || !this.renderer) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.cameraCtrl.setAspect(w / h);
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setSize(w, h);
    }
    if (this.bloomPass) {
      this.bloomPass.resolution.set(w, h);
    }
  };

  public loadRealm(realmId: number) {
    this.playerData.currentRealm = realmId;
    savePlayerData(this.playerData);

    // Reset realm battle performance statistics
    this.realmEnemiesDefeated = 0;
    this.realmPeakCombo = 0;
    this.realmEmbersEarned = 0;
    this.realmElapsedSeconds = 0;

    // Clean previous enemies, boss, pickups, hazards, and memory fragments
    this.enemies.forEach(e => {
      this.scene.remove(e.group);
    });
    this.enemies = [];

    if (this.currentBoss) {
      this.scene.remove(this.currentBoss.group);
      this.currentBoss = null;
    }

    this.healthPickups.forEach(p => {
      this.scene.remove(p.group);
      p.dispose();
    });
    this.healthPickups = [];

    this.spikeTraps.forEach(t => {
      this.scene.remove(t.group);
      t.dispose();
    });
    this.spikeTraps = [];

    this.burningBraziers.forEach(b => {
      this.scene.remove(b.group);
      b.dispose();
    });
    this.burningBraziers = [];

    this.memoryFragments.forEach(f => {
      this.scene.remove(f.group);
      f.dispose();
    });
    this.memoryFragments = [];
    this.currentMemoryLog = null;
    this.memoryLogTimer = 0;

    // Build World & Ambient Pad
    const def = this.realmWorld.buildRealm(realmId, this.scene);
    soundEngine.startDarkAmbientPad(realmId);

    // Spawn Realm Environmental Hazards (Tactical choke points for kiting demons)
    const spikePositions = [
      new THREE.Vector3(6.5, 0, -5),
      new THREE.Vector3(-6.5, 0, -5),
      new THREE.Vector3(8.0, 0, -14),
      new THREE.Vector3(-8.0, 0, -14),
    ];
    spikePositions.forEach(pos => {
      const trap = new FloorSpikeTrap(pos);
      this.scene.add(trap.group);
      this.spikeTraps.push(trap);
    });

    const brazierPositions = [
      new THREE.Vector3(0, 0, -11),
      new THREE.Vector3(13, 0, 3),
      new THREE.Vector3(-13, 0, 3),
    ];
    brazierPositions.forEach(pos => {
      const brazier = new BurningBrazierHazard(pos);
      this.scene.add(brazier.group);
      this.burningBraziers.push(brazier);
    });

    // Reset Azrael position
    this.azrael.group.position.set(0, 0, 8);
    this.azrael.group.rotation.set(0, Math.PI, 0);
    this.azrael.isDead = false;
    this.azrael.deathProgress = 0;
    this.combat.health = this.combat.maxHealth;
    this.combat.stamina = this.combat.maxStamina;
    this.isGameOver = false;
    this.isVictory = false;

    if (realmId === 1) {
      // --- REALM 1: PROLOGUE STORYLINE EXPERIENCE ---
      // Do NOT spawn demons or boss immediately! Azrael awakens alone in the quiet ruins.
      this.storylinePhase = 'exploration';
      this.collectedFragmentsCount = 0;
      this.currentObjective = "Prologue: Explore the silent ruins and uncover Azrael's memories (0/3)";

      // 3 Scattered 3D Memory Fragment Crystals
      const fragmentDefs = [
        {
          id: 'frag_crown',
          title: 'The Shattered Crown',
          text: 'A shattered crown lies buried in the cold ash. You remember kneeling before a high altar... but not whose name was praised.',
          position: new THREE.Vector3(10, 1.2, 6),
        },
        {
          id: 'frag_sword',
          title: 'The Celestial Cold',
          text: 'The greatsword in your grasp was forged in celestial ice. It hungers for demonic blood, yet it recoils from your own soul.',
          position: new THREE.Vector3(-11, 1.2, 3),
        },
        {
          id: 'frag_seals',
          title: 'The Seven Seals',
          text: 'Seven gates were unsealed to contain a single sovereign. Was it the demonic lords they feared... or you?',
          position: new THREE.Vector3(0, 1.2, -6),
        },
      ];

      fragmentDefs.forEach(fd => {
        const frag = new MemoryFragment(fd);
        this.memoryFragments.push(frag);
        this.scene.add(frag.group);
      });
    } else {
      // Realms 2 to 7: Standard Realm Incursions
      this.storylinePhase = 'boss';
      this.currentObjective = `Defeat ${def.bossName} - ${def.subtitle}`;

      // Spawn Guardian Demons
      const enemyConfigs: { type: EnemyType; count: number }[] = [
        { type: 'hellspawn', count: 4 },
        { type: realmId > 2 ? 'hellbrute' : 'hellspawn', count: 2 },
        { type: realmId > 4 ? 'shade' : 'hellspawn', count: 2 },
      ];

      enemyConfigs.forEach(({ type, count }) => {
        for (let i = 0; i < count; i++) {
          const angle = Math.random() * Math.PI * 2;
          const dist = 10 + Math.random() * 12;
          const pos = new THREE.Vector3(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
          const enemy = new EnemyInstance(type, pos);
          this.enemies.push(enemy);
          this.scene.add(enemy.group);
        }
      });

      // Spawn Major Realm Boss
      this.currentBoss = new BossInstance(realmId);
      this.currentBoss.group.position.set(0, 0, -14);
      this.scene.add(this.currentBoss.group);
      soundEngine.playBossSpawnHorn();
      soundEngine.playBossMusic(realmId);
    }

    this.pushUIUpdate();
  }

  public triggerDemonicBreach() {
    if (this.storylinePhase !== 'exploration') return;
    this.storylinePhase = 'breach';
    this.currentObjective = 'Defend against the Demonic Breach';

    this.cameraCtrl.addScreenShake(0.85);
    soundEngine.playBossSpawnHorn();

    // Spawn first demonic breach wave
    const spawnPositions = [
      new THREE.Vector3(8, 0, -4),
      new THREE.Vector3(-8, 0, -4),
      new THREE.Vector3(0, 0, -12),
      new THREE.Vector3(5, 0, 12),
    ];

    spawnPositions.forEach((pos, idx) => {
      const type: EnemyType = idx === 2 ? 'hellbrute' : 'hellspawn';
      const enemy = new EnemyInstance(type, pos);
      this.enemies.push(enemy);
      this.scene.add(enemy.group);
      this.particles.spawnGroundShockwave(pos, 3.5, 0xef4444);
    });

    this.pushUIUpdate();
  }

  public triggerBossArrival() {
    if (this.currentBoss) return;
    this.storylinePhase = 'boss';
    this.currentObjective = 'Confront The Hollow King - Ruler of Limbo';

    this.cameraCtrl.addScreenShake(1.1);
    soundEngine.playBossSpawnHorn();
    soundEngine.playBossMusic(1);

    this.currentBoss = new BossInstance(1);
    this.currentBoss.group.position.set(0, 0, -14);
    this.scene.add(this.currentBoss.group);
    this.particles.spawnGroundShockwave(new THREE.Vector3(0, 0, -14), 7.0, 0x38bdf8);

    this.pushUIUpdate();
  }

  public switchStance() {
    let next: CombatStance = 'reaper';
    if (this.azrael.currentStance === 'reaper') next = 'executioner';
    else if (this.azrael.currentStance === 'executioner') next = 'reaper';
    this.azrael.setStance(next);
    this.pushUIUpdate();
  }

  public activateWrath() {
    this.combat.activateWrath(this.azrael, this.particles);
    this.pushUIUpdate();
  }

  public upgradeStat(stat: keyof typeof this.playerData.stats) {
    const cost = 50 + this.playerData.level * 25;
    if (this.playerData.embers >= cost) {
      this.playerData.embers -= cost;
      this.playerData.level += 1;
      this.playerData.stats[stat] += 1;
      this.combat.recalculateStats(this.playerData.stats);
      savePlayerData(this.playerData);
      soundEngine.playVictoryChime();
      this.pushUIUpdate();
    }
  }

  public setGraphicsPreset(preset: GraphicsPreset) {
    this.graphicsPreset = preset;
    if (preset === 'ultra') {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2.0));
      this.renderer.toneMappingExposure = 1.25;
      if (this.bloomPass) {
        this.bloomPass.enabled = true;
        this.bloomPass.strength = 1.35;
        this.bloomPass.radius = 0.75;
        this.bloomPass.threshold = 0.7;
      }
      if (this.dirLight) {
        this.dirLight.castShadow = true;
        this.dirLight.shadow.mapSize.set(2048, 2048);
      }
    } else if (preset === 'balanced') {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
      this.renderer.toneMappingExposure = 1.15;
      if (this.bloomPass) {
        this.bloomPass.enabled = true;
        this.bloomPass.strength = 0.85;
        this.bloomPass.radius = 0.45;
        this.bloomPass.threshold = 0.82;
      }
      if (this.dirLight) {
        this.dirLight.castShadow = true;
        this.dirLight.shadow.mapSize.set(1024, 1024);
      }
    } else {
      this.renderer.setPixelRatio(1.0);
      this.renderer.toneMappingExposure = 1.05;
      if (this.bloomPass) {
        this.bloomPass.enabled = false;
      }
      if (this.dirLight) {
        this.dirLight.castShadow = false;
      }
    }
    this.pushUIUpdate();
  }

  public cycleGraphicsPreset(): GraphicsPreset {
    const order: GraphicsPreset[] = ['ultra', 'balanced', 'low'];
    const nextIdx = (order.indexOf(this.graphicsPreset) + 1) % order.length;
    this.setGraphicsPreset(order[nextIdx]);
    return this.graphicsPreset;
  }

  public triggerMobileAction(action: 'light' | 'heavy' | 'dodge' | 'stance' | 'ability' | 'wrath' | 'lock') {
    this.inputMgr.triggerAction(action);
  }

  public setVirtualMove(x: number, z: number) {
    this.inputMgr.setVirtualMove(x, z);
  }

  public setVirtualLook(dx: number, dy: number) {
    this.inputMgr.setVirtualLookDelta(dx, dy);
  }

  public restartRealm() {
    this.loadRealm(this.playerData.currentRealm);
  }

  private isAdvancingRealm: boolean = false;

  public advanceToNextRealm() {
    if (this.isAdvancingRealm) return;
    this.isAdvancingRealm = true;

    const nextRealm = this.playerData.currentRealm + 1;
    if (nextRealm <= 7) {
      if (!this.playerData.unlockedRealms.includes(nextRealm)) {
        this.playerData.unlockedRealms.push(nextRealm);
      }
      this.loadRealm(nextRealm);
    }

    setTimeout(() => {
      this.isAdvancingRealm = false;
    }, 800);
  }

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.clock.start();
    this.tick();
  }

  public stop() {
    this.isRunning = false;
    cancelAnimationFrame(this.animFrameId);
  }

  private tick = () => {
    if (!this.isRunning) return;
    this.animFrameId = requestAnimationFrame(this.tick);

    const delta = Math.min(this.clock.getDelta(), 0.1);

    // 1. Combat Hitstop check
    const isPaused = this.combat.update(delta);
    if (!isPaused) {
      this.updateGameLogic(delta);
    }

    // 2. Render Scene via UE5 Multi-Pass Composer (Ultra/Balanced) or Direct WebGL (Low)
    if ((this.graphicsPreset === 'ultra' || this.graphicsPreset === 'balanced') && this.composer) {
      this.composer.render();
    } else {
      this.renderer.render(this.scene, this.cameraCtrl.camera);
    }
  };

  private updateGameLogic(delta: number) {
    const input = this.inputMgr.update();

    // Track active battle stats while realm is in progress
    if (!this.isGameOver && !this.isVictory) {
      this.realmElapsedSeconds += delta;
      if (this.combat.comboCount > this.realmPeakCombo) {
        this.realmPeakCombo = this.combat.comboCount;
      }
    }

    // Stance switch key (Q)
    if (input.switchStance) {
      this.switchStance();
    }

    // Wrath ultimate key (R)
    if (input.wrathUltimate) {
      this.activateWrath();
    }

    // Special ability key (E) - Heavy Shockwave
    if (input.specialAbility) {
      this.combat.executeAttack(true, this.azrael, this.enemies, this.currentBoss, this.particles, this.playerData.stats);
    }

    // Check Lock-On (Tab)
    if (input.toggleLockOn) {
      if (this.cameraCtrl.lockTarget) {
        this.cameraCtrl.lockTarget = null;
      } else if (this.currentBoss && !this.currentBoss.isDead) {
        this.cameraCtrl.lockTarget = this.currentBoss.group.position;
      } else {
        const nearest = this.enemies.find(e => !e.isDead);
        if (nearest) this.cameraCtrl.lockTarget = nearest.group.position;
      }
    }

    // 1. Azrael Movement & Orientation
    let isMoving = false;
    if (!this.azrael.isDead && !this.azrael.isAttacking && !this.azrael.isDodging) {
      const moveVec = new THREE.Vector3(input.moveX, 0, -input.moveZ);
      if (moveVec.lengthSq() > 0.001) {
        isMoving = true;
        // Transform move vector relative to camera yaw
        moveVec.applyAxisAngle(new THREE.Vector3(0, 1, 0), this.cameraCtrl.yaw);

        // Face movement direction
        const targetAngle = Math.atan2(moveVec.x, moveVec.z);
        this.azrael.group.rotation.y = THREE.MathUtils.damp(this.azrael.group.rotation.y, targetAngle, 14, delta);

        // Move player
        const speed = input.isSprinting ? 9.0 : 5.5;
        this.azrael.group.position.addScaledVector(moveVec, speed * delta);

        // Arena boundary limit (radius 35m)
        const d = this.azrael.group.position.length();
        if (d > 35) {
          this.azrael.group.position.setLength(35);
        }
      }
    }

    // 2. Dodge Roll
    if (input.dodge) {
      this.combat.tryDodge(this.azrael);
    }

    // 3. Attacks
    if (input.attackLight) {
      const res = this.combat.executeAttack(false, this.azrael, this.enemies, this.currentBoss, this.particles, this.playerData.stats);
      if (res.embersGained > 0) {
        this.realmEmbersEarned += res.embersGained;
        this.playerData.embers += res.embersGained;
        savePlayerData(this.playerData);
      }
      if (res.hitLanded) {
        if (this.combat.comboCount > this.realmPeakCombo) {
          this.realmPeakCombo = this.combat.comboCount;
        }
        this.cameraCtrl.addScreenShake(0.3 + Math.min(0.3, this.combat.comboCount * 0.02));
      }
      if (res.defeatedEnemies && res.defeatedEnemies.length > 0) {
        this.realmEnemiesDefeated += res.defeatedEnemies.length;
        for (const defEnemy of res.defeatedEnemies) {
          if (Math.random() < 0.38) {
            const pickup = new HealthPickup(defEnemy.group.position);
            this.scene.add(pickup.group);
            this.healthPickups.push(pickup);
            this.particles.spawnSparks(defEnemy.group.position, 20, 0xef4444);
          }
        }
      }
    } else if (input.attackHeavy) {
      const res = this.combat.executeAttack(true, this.azrael, this.enemies, this.currentBoss, this.particles, this.playerData.stats);
      if (res.embersGained > 0) {
        this.realmEmbersEarned += res.embersGained;
        this.playerData.embers += res.embersGained;
        savePlayerData(this.playerData);
      }
      if (res.hitLanded) {
        if (this.combat.comboCount > this.realmPeakCombo) {
          this.realmPeakCombo = this.combat.comboCount;
        }
        this.cameraCtrl.addScreenShake(0.65 + Math.min(0.4, this.combat.comboCount * 0.03));
      }
      if (res.defeatedEnemies && res.defeatedEnemies.length > 0) {
        this.realmEnemiesDefeated += res.defeatedEnemies.length;
        for (const defEnemy of res.defeatedEnemies) {
          if (Math.random() < 0.45) {
            const pickup = new HealthPickup(defEnemy.group.position);
            this.scene.add(pickup.group);
            this.healthPickups.push(pickup);
            this.particles.spawnSparks(defEnemy.group.position, 20, 0xef4444);
          }
        }
      }
    }

    // 4. Update Azrael Kinematics
    this.azrael.update(delta, isMoving, input.isSprinting);

    // 4.5. Update 3D Memory Fragments & Proximity Detection (Non-blocking)
    const playerPos = this.azrael.group.position;
    for (let i = this.memoryFragments.length - 1; i >= 0; i--) {
      const frag = this.memoryFragments[i];
      const done = frag.update(delta);
      if (done) {
        this.scene.remove(frag.group);
        frag.dispose();
        this.memoryFragments.splice(i, 1);
        continue;
      }

      if (!frag.isCollected && frag.checkProximity(playerPos, 3.2)) {
        frag.collect();
        soundEngine.playMemoryChime();
        this.particles.spawnSparks(frag.group.position, 35, 0x38bdf8);
        this.currentMemoryLog = { title: frag.title, text: frag.text };
        this.memoryLogTimer = 7.5;
        this.collectedFragmentsCount += 1;

        if (!this.playerData.loreDiscovered.includes(frag.title)) {
          this.playerData.loreDiscovered.push(frag.title);
          savePlayerData(this.playerData);
        }

        this.currentObjective = `Prologue: Uncover Azrael's memories (${this.collectedFragmentsCount}/3)`;

        // Story trigger: Collecting fragments summons the demonic breach!
        if (this.collectedFragmentsCount >= 2 && this.storylinePhase === 'exploration') {
          setTimeout(() => {
            this.triggerDemonicBreach();
          }, 2400);
        }
      }
    }

    // Decay memory log display timer
    if (this.memoryLogTimer > 0) {
      this.memoryLogTimer -= delta;
      if (this.memoryLogTimer <= 0) {
        this.currentMemoryLog = null;
      }
    }

    // In breach phase, summon The Hollow King when wave is defeated or player reaches Hellgate
    if (this.storylinePhase === 'breach' && !this.currentBoss) {
      const remainingEnemies = this.enemies.filter(e => !e.isDead);
      const distToHellgate = playerPos.distanceTo(new THREE.Vector3(0, 0, -22));
      if (remainingEnemies.length === 0 || distToHellgate < 15) {
        this.triggerBossArrival();
      }
    }

    // 5. Update Enemies & Dynamic Combat Music State
    let minEnemyDist = 999;
    for (const enemy of this.enemies) {
      if (!enemy.isDead) {
        const dist = enemy.group.position.distanceTo(playerPos);
        if (dist < minEnemyDist) minEnemyDist = dist;
      }
      const result = enemy.update(delta, playerPos);
      if (result.damageDealt > 0) {
        const killed = this.combat.takePlayerDamage(result.damageDealt, this.particles, playerPos);
        this.cameraCtrl.addScreenShake(0.5);
        if (killed) {
          this.azrael.isDead = true;
          this.isGameOver = true;
        }
      }
    }

    const hasActiveBoss = Boolean(this.currentBoss && !this.currentBoss.isDead);
    soundEngine.updateCombatState(delta, minEnemyDist, hasActiveBoss);

    // 6. Update Boss
    if (this.currentBoss) {
      const bossResult = this.currentBoss.update(delta, playerPos);
      if (bossResult.damage > 0) {
        const killed = this.combat.takePlayerDamage(bossResult.damage, this.particles, playerPos);
        this.cameraCtrl.addScreenShake(0.75);
        if (killed) {
          this.azrael.isDead = true;
          this.isGameOver = true;
        }
      }
      if (bossResult.isShockwave && bossResult.shockwavePos) {
        this.particles.spawnGroundShockwave(bossResult.shockwavePos, 5.5, 0xef4444);
        this.cameraCtrl.addScreenShake(0.9);
      }

      // Boss Defeated Check
      if (this.currentBoss.isDead && !this.isVictory) {
        this.handleBossDefeated();
      }
    }

    // 6.5. Update Health Pickups (Supernatural Crimson Orbs)
    for (let i = this.healthPickups.length - 1; i >= 0; i--) {
      const p = this.healthPickups[i];
      const expired = p.update(delta);
      if (expired) {
        this.scene.remove(p.group);
        p.dispose();
        this.healthPickups.splice(i, 1);
        continue;
      }

      if (p.checkProximity(playerPos, 1.8)) {
        const heal = p.collect();
        this.combat.restoreHealth(heal);
        soundEngine.playHealthPickup();
        this.particles.spawnSparks(p.group.position, 28, 0xef4444);
        this.scene.remove(p.group);
        p.dispose();
        this.healthPickups.splice(i, 1);
      }
    }

    // 6.6. Update Environmental Hazards (Floor Spikes & Burning Braziers)
    for (const trap of this.spikeTraps) {
      trap.update(delta, this.azrael, this.combat, this.enemies, this.currentBoss, this.particles);
    }
    for (const brazier of this.burningBraziers) {
      brazier.update(delta, this.azrael, this.combat, this.enemies, this.currentBoss, this.particles);
    }

    // 6.7. Audio Zone System (Ruins vs Central Arena vs Hellgate Portal)
    let audioZone: 'ruins' | 'arena' | 'hellgate' = 'arena';
    const distToHellgate = playerPos.distanceTo(new THREE.Vector3(0, 0, -22));
    if (distToHellgate < 12.0) {
      audioZone = 'hellgate';
    } else if (new THREE.Vector2(playerPos.x, playerPos.z).length() > 20.0) {
      audioZone = 'ruins';
    }
    soundEngine.updateAudioZone(audioZone, delta);

    // 7. Update Realm World, Particles & Combat System
    this.realmWorld.update(delta);
    this.particles.update(delta, this.azrael.group.position, this.realmWorld.currentRealmDef?.accentColor);
    this.combat.update(delta, minEnemyDist < 12.0 || hasActiveBoss);

    // 8. White-Eyed God Secret Sequence Update
    if (this.isWhiteEyedGodActive) {
      this.whiteEyedGodTimer += delta;
      this.whiteEyedGod.update(delta);
      // Turn camera to face the looming void eyes
      this.cameraCtrl.camera.position.set(0, 3, 5);
      this.cameraCtrl.camera.lookAt(0, 6, -18);
    } else {
      // Normal camera track with dynamic combat FOV & combo shake
      this.cameraCtrl.update(delta, this.azrael.group.position, input.lookX, input.lookY, this.combat.comboCount, minEnemyDist < 14 || hasActiveBoss);
    }

    this.pushUIUpdate();
  }

  private handleBossDefeated() {
    this.isVictory = true;
    this.realmEnemiesDefeated += 1;
    this.realmEmbersEarned += 500 + this.playerData.currentRealm * 250;
    soundEngine.playVictoryChime();
    soundEngine.playExplorationMusic(this.playerData.currentRealm);

    const def = REALM_DEFINITIONS.find(r => r.id === this.playerData.currentRealm);
    if (def) {
      this.activeLore = {
        title: def.loreTitle,
        text: def.loreFragment,
      };
      if (!this.playerData.loreDiscovered.includes(def.loreTitle)) {
        this.playerData.loreDiscovered.push(def.loreTitle);
      }
    }

    // Unlock next realm
    const next = this.playerData.currentRealm + 1;
    if (next <= 7 && !this.playerData.unlockedRealms.includes(next)) {
      this.playerData.unlockedRealms.push(next);
    }

    if (!this.playerData.defeatedBosses.includes(this.currentBoss?.name || '')) {
      this.playerData.defeatedBosses.push(this.currentBoss?.name || '');
    }
    savePlayerData(this.playerData);

    // If Realm 7 was defeated, trigger THE WHITE-EYED GOD reveal!
    if (this.playerData.currentRealm === 7) {
      setTimeout(() => {
        this.triggerWhiteEyedGodReveal();
      }, 3500);
    }
  }

  public triggerWhiteEyedGodReveal() {
    this.isWhiteEyedGodActive = true;
    this.whiteEyedGodTimer = 0;
    this.whiteEyedGod.group.visible = true;

    // Plunge entire scene into absolute void blackness
    this.scene.background = new THREE.Color(0x000000);
    this.scene.fog = new THREE.FogExp2(0x000000, 0.05);

    // Hide arena props and enemies
    this.realmWorld.group.visible = false;
    this.azrael.group.visible = false;
    if (this.currentBoss) this.currentBoss.group.visible = false;
    this.enemies.forEach(e => e.group.visible = false);

    soundEngine.stopDarkAmbientPad();
    soundEngine.playWhiteEyedGodWhisper();
  }

  private pushUIUpdate() {
    const curRealmDef = REALM_DEFINITIONS.find(r => r.id === this.playerData.currentRealm) || REALM_DEFINITIONS[0];
    this.onUIUpdate({
      health: this.combat.health,
      maxHealth: this.combat.maxHealth,
      stamina: this.combat.stamina,
      maxStamina: this.combat.maxStamina,
      wrath: this.combat.wrath,
      maxWrath: this.combat.maxWrath,
      stance: this.azrael.currentStance,
      level: this.playerData.level,
      embers: this.playerData.embers,
      currentRealm: curRealmDef,
      bossHealth: this.currentBoss ? this.currentBoss.currentHealth : null,
      bossMaxHealth: this.currentBoss ? this.currentBoss.maxHealth : null,
      bossName: this.currentBoss ? this.currentBoss.name : null,
      bossPhase: this.currentBoss ? this.currentBoss.phase : 1,
      isGameOver: this.isGameOver,
      isVictory: this.isVictory,
      unlockedRealms: this.playerData.unlockedRealms,
      loreFragment: this.activeLore,
      isWhiteEyedGodActive: this.isWhiteEyedGodActive,
      whiteEyedGodProgress: Math.min(1, this.whiteEyedGodTimer / 7.0),
      graphicsPreset: this.graphicsPreset,
      currentMemoryLog: this.currentMemoryLog,
      currentObjective: this.currentObjective,
      isHealing: this.combat.healIndicatorTimer > 0,
      isPassivelyRegenerating: this.combat.isPassivelyRegenerating,
      comboCount: this.combat.comboCount,
      comboTimerPercent: Math.max(0, Math.min(100, (this.combat.comboMultiplierTimer / 3.2) * 100)),
      comboMultiplier: this.combat.getComboMultiplier(),
      battleStats: {
        enemiesDefeated: this.realmEnemiesDefeated,
        peakCombo: Math.max(this.realmPeakCombo, this.combat.comboCount),
        embersEarned: this.realmEmbersEarned,
        elapsedSeconds: Math.floor(this.realmElapsedSeconds),
        bossName: this.currentBoss ? this.currentBoss.name : curRealmDef.bossName,
      },
    });
  }

  public dispose() {
    this.stop();
    window.removeEventListener('resize', this.handleResize);
    this.healthPickups.forEach(p => p.dispose());
    this.spikeTraps.forEach(t => t.dispose());
    this.burningBraziers.forEach(b => b.dispose());
    this.composer?.dispose();
    this.renderer.dispose();
    this.particles.dispose();
  }
}
