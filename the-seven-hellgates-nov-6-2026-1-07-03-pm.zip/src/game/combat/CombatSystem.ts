/**
 * The Seven Hellgates - Soulslike Combat System
 * Stamina management, i-frame dodging, hitbox detection, combo chaining, and hitstop.
 */

import * as THREE from 'three';
import { CombatStance, FloatingText, PlayerStats } from '../types';
import { AzraelModel } from '../entities/AzraelModel';
import { EnemyInstance } from '../entities/EnemyModels';
import { BossInstance } from '../entities/BossModels';
import { ParticleSystem } from '../vfx/ParticleSystem';
import { soundEngine } from '../audio/SoundEngine';

export class CombatSystem {
  public health: number;
  public maxHealth: number;
  public stamina: number;
  public maxStamina: number;
  public wrath: number;
  public maxWrath: number = 100;

  // Health Regeneration System
  public timeSinceLastDamage: number = 999;
  public healIndicatorTimer: number = 0;
  public isPassivelyRegenerating: boolean = false;
  private awardedDefeatHealthEnemyIds = new Set<string>();

  // Combo Counter & Wrath Multiplier
  public comboCount: number = 0;
  public comboMultiplierTimer: number = 0;

  public getComboTier(count: number = this.comboCount): number {
    if (count >= 20) return 4;
    if (count >= 12) return 3;
    if (count >= 6) return 2;
    if (count >= 2) return 1;
    return 0;
  }

  public getComboMultiplier(): number {
    return 1.0 + Math.min(1.5, Math.floor(this.comboCount / 4) * 0.25);
  }

  public registerHitLanded() {
    const prevTier = this.getComboTier();
    this.comboCount++;
    this.comboMultiplierTimer = 3.2; // 3.2s combo decay window
    const newTier = this.getComboTier();
    if (newTier > prevTier && newTier >= 1) {
      soundEngine.playComboRankUp(newTier);
    }
  }

  private staminaRegenDelay: number = 0;
  private comboStep: number = 1;
  private comboTimer: number = 0;
  public iFramesActive: boolean = false;
  private iFramesTimer: number = 0;
  private hitstopTimer: number = 0;

  public floatingTexts: FloatingText[] = [];

  constructor(stats: PlayerStats) {
    this.maxHealth = 100 + stats.vitality * 15;
    this.health = this.maxHealth;
    this.maxStamina = 80 + stats.vigor * 10;
    this.stamina = this.maxStamina;
    this.wrath = 20;
  }

  public recalculateStats(stats: PlayerStats) {
    const healthPercent = this.health / this.maxHealth;
    this.maxHealth = 100 + stats.vitality * 15;
    this.health = this.maxHealth * healthPercent;

    const stamPercent = this.stamina / this.maxStamina;
    this.maxStamina = 80 + stats.vigor * 10;
    this.stamina = this.maxStamina * stamPercent;
  }

  /**
   * Restores health up to maximum (250). Cannot revive dead Azrael.
   */
  public restoreHealth(amount: number): number {
    if (this.health <= 0 || amount <= 0) return 0;
    const healed = Math.min(amount, this.maxHealth - this.health);
    if (healed > 0) {
      this.health = Math.min(this.maxHealth, this.health + healed);
      this.healIndicatorTimer = 0.8;
    }
    return healed;
  }

  public resetDamageTimer() {
    this.timeSinceLastDamage = 0;
    this.isPassivelyRegenerating = false;
  }

  public awardEnemyDefeatHealth(enemy: EnemyInstance) {
    const id = enemy.id || `${enemy.stats.name}_${enemy.group.position.x.toFixed(1)}_${enemy.group.position.z.toFixed(1)}`;
    if (this.awardedDefeatHealthEnemyIds.has(id)) return;
    this.awardedDefeatHealthEnemyIds.add(id);

    const isElite = enemy.stats.name.toLowerCase().includes('elite') ||
      enemy.stats.type === 'hellbrute' ||
      enemy.stats.type === 'butcher';
    const healAmount = isElite ? 15 : 8;
    this.restoreHealth(healAmount);
  }

  public awardBossDefeatHealth(bossKey: string) {
    if (this.awardedDefeatHealthEnemyIds.has(bossKey)) return;
    this.awardedDefeatHealthEnemyIds.add(bossKey);
    this.restoreHealth(25);
  }

  public update(delta: number, isEngagedWithEnemies: boolean = false): boolean {
    // Return true if hitstop is currently pausing frames
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= delta;
      return true;
    }

    this.timeSinceLastDamage += delta;
    if (this.healIndicatorTimer > 0) {
      this.healIndicatorTimer -= delta;
    }

    // 0. Passive Health Regeneration:
    // After 10s without damage, regen 4 HP/sec, only when no enemies actively engaging
    if (!isEngagedWithEnemies && this.timeSinceLastDamage >= 10.0 && this.health > 0 && this.health < this.maxHealth) {
      this.isPassivelyRegenerating = true;
      this.restoreHealth(4 * delta);
    } else {
      this.isPassivelyRegenerating = false;
    }

    // 1. Combo Window Decay
    if (this.comboMultiplierTimer > 0) {
      this.comboMultiplierTimer -= delta;
      if (this.comboMultiplierTimer <= 0) {
        this.comboCount = 0;
      }
    }

    // 2. Stamina Regeneration
    if (this.staminaRegenDelay > 0) {
      this.staminaRegenDelay -= delta;
    } else if (this.stamina < this.maxStamina) {
      this.stamina = Math.min(this.maxStamina, this.stamina + 35 * delta);
    }

    // 3. I-Frames timer
    if (this.iFramesActive) {
      this.iFramesTimer -= delta;
      if (this.iFramesTimer <= 0) {
        this.iFramesActive = false;
      }
    }

    // 4. Combo step window decay
    if (this.comboTimer > 0) {
      this.comboTimer -= delta;
      if (this.comboTimer <= 0) {
        this.comboStep = 1;
      }
    }

    // 5. Update floating combat text
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const ft = this.floatingTexts[i];
      ft.opacity -= delta * 1.5;
      ft.y -= delta * 30;
      if (ft.opacity <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }

    return false;
  }

  public tryDodge(azrael: AzraelModel): boolean {
    if (this.stamina < 20 || azrael.isDodging || azrael.isDead) return false;
    this.stamina -= 20;
    this.staminaRegenDelay = 0.55;
    this.iFramesActive = true;
    this.iFramesTimer = 0.35; // 350ms of invulnerability
    azrael.isDodging = true;
    azrael.dodgeProgress = 0;
    soundEngine.playDodgeRoll();
    return true;
  }

  public executeAttack(
    isHeavy: boolean,
    azrael: AzraelModel,
    enemies: EnemyInstance[],
    boss: BossInstance | null,
    particles: ParticleSystem,
    stats: PlayerStats
  ): { embersGained: number; hitLanded: boolean; defeatedEnemies: EnemyInstance[]; bossDefeated: boolean } {
    if (azrael.isAttacking || azrael.isDodging || azrael.isDead) return { embersGained: 0, hitLanded: false, defeatedEnemies: [], bossDefeated: false };

    const staminaCost = isHeavy ? 30 : 16;
    if (this.stamina < staminaCost) {
      // Out of stamina penalty
      soundEngine.playSwordSwing(0.6);
      return { embersGained: 0, hitLanded: false, defeatedEnemies: [], bossDefeated: false };
    }

    this.stamina -= staminaCost;
    this.staminaRegenDelay = 0.7;

    const currentStep = isHeavy ? 1 : this.comboStep;
    azrael.triggerAttack(currentStep, isHeavy);

    // Audio SFX
    if (azrael.currentStance === 'executioner') {
      soundEngine.playGauntletPunch();
    } else if (isHeavy) {
      soundEngine.playHeavySlash();
    } else {
      soundEngine.playSwordSwing(1.0 + (currentStep - 1) * 0.15);
    }

    // Visual slash arc
    const slashColor = azrael.currentStance === 'wrath_unbound'
      ? 0x60a5fa
      : (azrael.currentStance === 'executioner' ? 0xf59e0b : 0x38bdf8);
    particles.spawnSlashArc(azrael.group.position, azrael.group.rotation, slashColor, isHeavy);

    // Base damage calculation based on stance and player strength
    let baseDamage = (isHeavy ? 65 : (28 + currentStep * 8)) + stats.strength * 3.5;
    if (azrael.currentStance === 'wrath_unbound') {
      baseDamage *= 1.6;
    } else if (azrael.currentStance === 'executioner') {
      baseDamage *= 1.25;
    }

    let hitLanded = false;
    let embersGained = 0;
    const defeatedEnemies: EnemyInstance[] = [];
    let bossDefeated = false;
    const playerPos = azrael.group.position;
    const playerForward = new THREE.Vector3(0, 0, 1).applyEuler(azrael.group.rotation);
    const attackRange = isHeavy ? 3.4 : (azrael.currentStance === 'executioner' ? 2.3 : 2.9);

    // 1. Check hits against standard enemies
    for (const enemy of enemies) {
      if (enemy.isDead) continue;
      const toEnemy = new THREE.Vector3().subVectors(enemy.group.position, playerPos);
      toEnemy.y = 0;
      const dist = toEnemy.length();

      if (dist <= attackRange) {
        toEnemy.normalize();
        const angle = playerForward.dot(toEnemy);
        // 120 degree frontal arc
        if (angle > 0.3 || dist <= 1.2) {
          hitLanded = true;
          const damage = Math.round(baseDamage * (0.9 + Math.random() * 0.2));
          enemy.takeDamage(damage);

          // Build combo counter & wrath with combo multiplier
          this.registerHitLanded();
          const wrathMult = this.getComboMultiplier();
          this.wrath = Math.min(this.maxWrath, this.wrath + (isHeavy ? 12 : 6) * wrathMult);

          // Effects
          particles.spawnSparks(enemy.group.position, 16, slashColor);
          particles.spawnBlood(enemy.group.position, 12);
          soundEngine.playHitImpact(isHeavy);
          this.triggerHitstop(0.045);

          // Heavy knockback
          if (isHeavy) {
            enemy.group.position.addScaledVector(playerForward, 1.2);
            particles.spawnGroundShockwave(enemy.group.position, 2.8, slashColor);
          }

          if (enemy.isDead) {
            embersGained += enemy.stats.emberReward;
            soundEngine.playEnemyDeath();
            this.awardEnemyDefeatHealth(enemy);
            defeatedEnemies.push(enemy);
          }
        }
      }
    }

    // 2. Check hit against Boss
    if (boss && !boss.isDead) {
      const toBoss = new THREE.Vector3().subVectors(boss.group.position, playerPos);
      toBoss.y = 0;
      const dist = toBoss.length();
      if (dist <= attackRange + 1.2) {
        hitLanded = true;
        const damage = Math.round(baseDamage * (0.85 + Math.random() * 0.3));
        boss.takeDamage(damage);

        this.registerHitLanded();
        const wrathMult = this.getComboMultiplier();
        this.wrath = Math.min(this.maxWrath, this.wrath + (isHeavy ? 15 : 8) * wrathMult);

        particles.spawnSparks(boss.group.position, 25, slashColor);
        soundEngine.playHitImpact(isHeavy);
        this.triggerHitstop(0.05);

        if (isHeavy) {
          particles.spawnGroundShockwave(boss.group.position, 4.0, slashColor);
        }

        if (boss.isDead) {
          embersGained += 500 + boss.realmId * 250;
          this.awardBossDefeatHealth(boss.name);
          bossDefeated = true;
        }
      }
    }

    // Combo step progression
    if (!isHeavy) {
      this.comboStep = this.comboStep >= 3 ? 1 : this.comboStep + 1;
      this.comboTimer = 1.1; // 1.1s window to continue combo
    }

    return { embersGained, hitLanded, defeatedEnemies, bossDefeated };
  }

  public takePlayerDamage(amount: number, particles: ParticleSystem, azraelPos: THREE.Vector3): boolean {
    if (this.iFramesActive || this.health <= 0) {
      return false; // Dodged or already dead
    }

    this.resetDamageTimer();
    this.comboCount = 0;
    this.comboMultiplierTimer = 0;
    this.health = Math.max(0, this.health - amount);
    particles.spawnBlood(azraelPos, 20);
    soundEngine.playHitImpact(true);
    this.triggerHitstop(0.06);

    return this.health <= 0;
  }

  public activateWrath(azrael: AzraelModel, particles: ParticleSystem): boolean {
    if (this.wrath < 50 || azrael.isDead) return false;
    this.wrath = 0;
    azrael.setStance('wrath_unbound');
    soundEngine.playWrathActivation();
    particles.spawnGroundShockwave(azrael.group.position, 6.0, 0x60a5fa);
    particles.spawnSparks(azrael.group.position, 40, 0x93c5fd);

    // Stance wears off after 15 seconds
    setTimeout(() => {
      if (!azrael.isDead && azrael.currentStance === 'wrath_unbound') {
        azrael.setStance('reaper');
      }
    }, 15000);

    return true;
  }

  private triggerHitstop(duration: number) {
    this.hitstopTimer = duration;
  }
}
