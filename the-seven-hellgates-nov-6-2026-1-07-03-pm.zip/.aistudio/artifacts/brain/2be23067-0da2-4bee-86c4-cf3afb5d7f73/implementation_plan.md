# Multi-Slide Stage Completed & Hellgate Breach Sequence

A cinematic, two-slide victory and progression sequence that replaces the static victory banner with a comprehensive combat battle review slide and an immersive next-realm prophecy breach slide.

> [!IMPORTANT]
> **Confirmed User Decisions**:
> 1. **Slide Transition**: Step-by-step slides with responsive `Next` and `Back` navigation and pagination indicators.
> 2. **Slide 1 Content**: Full battle review featuring enemies vanquished, maximum combo achieved, embers collected, and boss soul purification badge.
> 3. **Slide 2 Content**: Next realm preview showcasing destination lore, demonic arch-boss prophecy, and the primary "Breach Hellgate" trigger (with secondary access to the Altar of Ash for attribute upgrades).

---

## 1. Overview & Core Concept

When Azrael slays an arch-demon and purifies a Hellgate, the victory experience transitions from a generic pop-up into a grand dark-fantasy milestone consisting of two distinct slides:

1. **Slide 1: Realm Cleared & Combat Chronicle**:
   Celebrates the player's triumph with a battle evaluation. It tallies enemies slain, peak combo multiplier unlocked, embers harvested, and time taken in the realm.

2. **Slide 2: Enter Next Hellgate & Demonic Prophecy**:
   Provides a narrative and tactical bridge to the next gate. It previews the upcoming realm’s biome, arch-demon lore, environmental hazards, and equips Azrael with the choice to breach immediately or reinforce attributes at the Altar of Ash first.

---

## 2. User Experience & Visual Design

### Key User Flows

```
[Boss Slain in 3D Arena]
        │
        ▼
[Slide 1: Stage Cleared & Battle Chronicle]
   • Arch-Demon Soul Purified Banner
   • Combat Stats Grid: Enemies Slain, Max Combo, Embers Gained, Realm Time
   • "Review Hellgate Threshold" ──► (Next Slide Button)
        │
        ▼
[Slide 2: Enter Next Hellgate]
   • Destination Gate Designation (e.g., "REALM II: LUST")
   • Arch-Demon Prophecy & Biome Briefing
   • Environmental Threat Warning (e.g. Hurricane Tempests, Spike Grates)
   • Actions:
       ├── [Breach Hellgate] ──► Loads Next Realm in 3D Engine & Starts Combat
       ├── [Altar of Ash]    ──► Opens Stat Leveling Modal
       └── [Back to Stats]   ──► Returns to Slide 1
```

### Visual Identity & Theme
- **Surface**: Deep obsidian frosted glass (`bg-black/92 backdrop-blur-xl border border-blue-900/50`) with subtle gothic corner accents and celestial azure glows.
- **Color Discipline (60-30-10)**:
  - 60% Obsidian and void dark neutrals (`#090A0F`, `#020408`).
  - 30% Structural slate borders and subdued ash gray typography (`#94A3B8`).
  - 10% Accents: Royal astral blue (`#2563EB`, `#38BDF8`) for celestial purification and Hellgate threshold breach.
- **Typography & Formatting**:
  - Headers: Cinzel / Gothic display typography (`font-gothic tracking-[0.2em] font-extrabold`).
  - Numbers & Metrics: Tabular numerals (`font-mono tabular-nums`) with clear unit labeling.
  - Zero-Pill Discipline: Battle statistics rendered in clean, unboxed metric pairs with subtle vertical hairline dividers, avoiding rounded capsule badges.
- **Slide Motion**: Smooth CSS horizontal slide transition (`translate-x-0` vs `-translate-x-full`) with fade effects.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dedicated Modal vs. Floating In-World Billboard**:
  - *Chosen Approach*: A centered modal overlay (`StageCompletionModal`) mounted on the HUD with high contrast and pointer capture.
  - *Why*: The post-boss victory moment is a major narrative reward and breather. Players need clear, legible text to review their combat numbers and read the next demon's prophecy without visual interference from remaining particles.

- **Decision 2: Slide Navigation Model**:
  - *Chosen Approach*: Explicit `Next Slide` and `Back` navigation buttons coupled with interactive step pagination dots.
  - *Why*: Keeps the user in full control, allowing players to flip back and forth between reading the next realm's prophecy and checking their combo/ember numbers before embarking.

- **Decision 3: Altar of Ash Access Before Gate Breach**:
  - *Chosen Approach*: Include an "Upgrade at Altar" shortcut directly on Slide 2 alongside "Breach Hellgate".
  - *Why*: Boss victories award massive embers (500–2,000 embers). Allowing the player to allocate these rewards before loading into the tougher subsequent realm prevents early deaths in higher gates.

---

## 4. Technical Architecture & Data Strategy

### Component Hierarchy

```
┌────────────────────────────────────────────────────────┐
│                        App.tsx                         │
│  (State: isVictory, currentRealm, playerData)          │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│                       GameHUD                          │
│  (Orchestrates HUD overlays, modals, and health bars)  │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│              StageCompletionModal.tsx                  │
│  • slide: 1 | 2                                        │
│  • currentRealm & nextRealm metadata                   │
│  • battleStats (enemiesSlain, peakCombo, embersEarned) │
├───────────────────────────┬────────────────────────────┤
│         Slide 1           │          Slide 2           │
│  [Battle Chronicle]       │  [Enter Next Hellgate]     │
│  - Realm Purified Hero    │  - Destination Realm Title │
│  - Boss Slain Memorial    │  - Arch-Demon Lore Briefing│
│  - Combat Stats Table     │  - Environmental Warnings  │
│  - "Review Hellgate" CTA  │  - "Breach Hellgate" CTA   │
│                           │  - "Visit Altar" Link      │
└───────────────────────────┴────────────────────────────┘
```

### Data Model & State Additions
1. **`RealmStats` in `CombatSystem` & `HellgatesGame`**:
   - `realmEnemiesDefeated`: Count of demonic grunts/elites defeated in the current realm session.
   - `realmPeakCombo`: Highest combo counter reached in the current realm run.
   - `realmEmbersEarned`: Cumulative embers gained in this realm session.
   - `realmDurationSeconds`: Clock time elapsed from realm entry to boss defeat.
2. **`GameUIState` Updates**:
   - Extend `GameUIState` with `battleStats: { enemiesDefeated: number; peakCombo: number; embersEarned: number; elapsedSeconds: number }`.
3. **`REALM_DEFINITIONS` Next-Realm Lookup**:
   - Safe lookup for `nextRealm = REALM_DEFINITIONS.find(r => r.id === currentRealm.id + 1)`. If Realm 7 was defeated, Slide 2 dynamically presents "The Final Threshold: The White-Eyed God".
